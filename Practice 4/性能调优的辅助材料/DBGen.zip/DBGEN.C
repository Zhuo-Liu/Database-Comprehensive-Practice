/********************************************************************
DbGen.c
*********************************************************************
(c)1999 Jim Gray(Gray@MICROSOFT.com)
These programs are provided "as is", without any express or implied warranty.
The program is freeware.  It is freely distributed subject to the restriction
that this Copyright be included with any distribution (so that we can
continue to disclaim responsibility for any problems that may arise from it).
*********************************************************************
For explanations see
Quickly Generating Billion-Record Synthetic Databases,
Jim Gray,  Prakash Sundaresan, Susanne Englert, Ken Baclawski,
Peter J. Weinberger, SIGMOD Conference 1994: 243-252.
An earlier version of the paper is at the web site
http://research.Microsoft.com/~Gray/SyntheticDataGen.doc.
********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <float.h>
#include <math.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>

#ifndef _CONSOLE
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <shellapi.h>
#endif

#ifndef NO_ODBC
#include <sql.h>
#include <sqlext.h>
#endif

/* buffer size defs */
#define XLARGEBUFF          1024
#define LARGEBUFF           300
#define SMALLBUFF           100
#define TINYBUFF            40
/* timestamp string size MM/DD/YYYY HH:MM */
#define TIME_SZ             16
/* max str size to int convertion */
#define CHAR95_SZ           10
/* max decades for Gen,Prim */
#define GEN_DECS            18
/* Number of columns in lv */
#define COL_NUM             12
/* Number of rows in granula */
#define GRAN_SZ             1000
/* indexes of columns */
#define COL_NAME            0
#define COL_TYPE            1
#define COL_LENGTH          2
#define COL_PREC            3
#define COL_SCALE           4
#define COL_DISTR           5
#define COL_MEAN            6
#define COL_STDDEV          7
#define COL_MIN             8
#define COL_MAX             9
#define COL_KEY             10
#define COL_UNIQUE          11
/* lv top left corn, w, h */
#define X_SHT               2
#define Y_SHT               54
#define W_SHT               780
#define H_SHT               290
#define W_MAIN              790
#define H_MAIN              408
/* number of distrs */
#define DISTR_NUM           7
/* distr indexes */
#define DISTR_RAND          0
#define DISTR_ORD           1
#define DISTR_GAUS          2
#define DISTR_EXPN          3
#define DISTR_POIS          4
#define DISTR_SSIM          5
#define DISTR_ZIPF          6
/* number of types */
#define TYPE_NUM            9
/* Type array inexes */
#define TYPE_INT            0
#define TYPE_SMALLINT       1
#define TYPE_TINYINT        2
#define TYPE_CHAR           3
#define TYPE_VARCHAR        4
#define TYPE_DECIMAL        5
#define TYPE_REAL           6
#define TYPE_FLOAT          7
#define TYPE_DATETIME       8
/* minutes passed from the year begining */
#define MONTH_0             0
#define MONTH_1             (31*24*60)
#define MONTH_2             (MONTH_1 + 28*24*60)
#define MONTH_3             (MONTH_2 + 31*24*60)
#define MONTH_4             (MONTH_3 + 30*24*60)
#define MONTH_5             (MONTH_4 + 31*24*60)
#define MONTH_6             (MONTH_5 + 30*24*60)
#define MONTH_7             (MONTH_6 + 31*24*60)
#define MONTH_8             (MONTH_7 + 31*24*60)
#define MONTH_9             (MONTH_8 + 30*24*60)
#define MONTH_10            (MONTH_9 + 31*24*60)
#define MONTH_11            (MONTH_10 + 30*24*60)
#define MONTH_12            (365*24*60)
/* commands id */
#define IDC_OK              1100
#define IDC_LEFT            1101
#define IDC_RIGHT           1102
#define IDC_SAVE            1103
#define IDC_LOAD            1104
/* number of toks */
#define TOK_NUM             22
/* init toks */
#define TOK_NAME            COL_NAME
#define TOK_TYPE            COL_TYPE
#define TOK_LENGTH          COL_LENGTH
#define TOK_PREC            COL_PREC
#define TOK_SCALE           COL_SCALE
#define TOK_DISTR           COL_DISTR
#define TOK_MEAN            COL_MEAN
#define TOK_STDDEV          COL_STDDEV
#define TOK_MIN             COL_MIN
#define TOK_MAX             COL_MAX
#define TOK_KEY             COL_KEY
#define TOK_UNIQUE          COL_UNIQUE
#define TOK_CONNECT         12
#define TOK_TABLE           13
#define TOK_FLDNUM          14
#define TOK_ROWNUM          15
#define TOK_DESTFILE        16
#define TOK_DESTODBC        17
#define TOK_DBGEN           18
#define TOK_H               19
#define TOK_A               20
#define TOK_OLDODBC         21
#define TOK_PRIME         	22
#define TOK_ROOT         	23
#define CHAR_LIKE(t) ((t)==TYPE_CHAR||(t)==TYPE_VARCHAR||(t)==TYPE_DECIMAL)
#define CONN_MS ("DRIVER={SQL Server};UID=sa;PWD=;SERVER=(local);DATABASE=tempdb;")
#define CONN_MY ("DRIVER={MySQL};UID=;PWD=;SERVER=localhost;DATABASE=test;")

#define I31 0x80000000
#define I62 0x4000000000000000
/* 4611686018427387904 */
#define I31_1 0x7FFFFFFF
#define I62_1 0x3FFFFFFFFFFFFFFF
/* max digits in 64int */
#define DEC_I64 19

#define BMI {{sizeof(BITMAPINFOHEADER),15,15,1,4,0,0,0,0,0,0},{{0,0,0,0},{0,0,0x80,0},\
    {0,0x80,0,0},{0,0x80,0x80,0},{0x80,0,0,0},{0x80,0,0x80,0},{0x80,0x80,0,0},\
    {0x80,0x80,0x80,0},{0xc0,0xc0,0xc0,0},{0,0,0xff,0},{0,0xff,0,0},{0,0xff,0xff,0},\
    {0xff,0,0,0},{0xff,0,0xff,0},{0xff,0xff,0,0},{0xff,0xff,0xff,0}}}
#define SAVEB {\
    0x88,0,0,0,0,0,0,0,0x80,0x77,0,0,0,0x88,0x7,0,0x80,0x77,0,0,0,0x88,0x7,0,0x80,0x77,\
    0,0,0,0x88,0x7,0,0x80,0x77,0,0,0,0,0x7,0,0x80,0x77,0x77,0x77,0x77,0x77,0x77,0,0x80,\
    0x77,0,0,0,0,0x77,0,0x80,0x70,0x88,0x88,0x88,0x88,0x7,0,0x80,0x70,0x88,0x88,0x88,0x88,\
    0x7,0,0x80,0x70,0x88,0x88,0x88,0x88,0x7,0,0x80,0x70,0x88,0x88,0x88,0x88,0x7,0,0x80,\
    0x70,0x88,0x88,0x88,0x88,0,0,0x80,0x70,0x88,0x88,0x88,0x88,0x8,0,0x80,0,0,0,0,0,0,0,\
0x88,0x88,0x88,0x88,0x88,0x88,0x88,0x80}
#define OPENB {\
    0x88,0x88,0x88,0x88,0x88,0x88,0x88,0x80,0,0,0,0,0,0x8,0x88,0x80,0,0x77,0x77,0x77,0x77,\
    0x70,0x88,0x80,0xf,0x7,0x70,0x7,0x77,0x77,0x8,0x80,0xf,0xf0,0x77,0x77,0x77,0x77,0x70,\
    0x80,0xf,0xff,0x7,0x77,0x77,0x77,0x77,0,0xf,0xff,0xf0,0,0,0,0,0,0xf,0xff,0xff,0xff,\
    0xff,0x8,0x88,0x80,0xf,0xff,0xff,0xff,0xff,0x8,0x88,0x80,0xf,0xff,0,0,0,0x8,0x88,0x80,\
    0x80,0,0x88,0x88,0x88,0x88,0,0,0x88,0x88,0x88,0x88,0x88,0x88,0x80,0,0x88,0x88,0x88,\
    0x88,0x8,0x88,0x8,0,0x88,0x88,0x88,0x88,0x80,0,0x88,0x80,0x88,0x88,0x88,0x88,0x88,0x88,\
0x88,0x80}

#define URL ("http://research.Microsoft.com/~Gray/DbGen/DbGen.Zip")

#define STR_TO_VAL(type, buf) ((type==TYPE_DECIMAL||type==TYPE_REAL||type==TYPE_FLOAT)?\
(ValidDbl(buf)?atof(buf):0.0):(type==TYPE_TINYINT||type==TYPE_SMALLINT||type==TYPE_INT)?\
(ValidDbl(buf)?atof(buf):0):(type==TYPE_DATETIME)?TimeToInt(buf):\
(type==TYPE_CHAR||type==TYPE_VARCHAR)?StrToInt(buf):0)

/* distr struct */
typedef struct _DistrAT {
    int             Distr;
    double          Mean;
    double          Deviat;
    double          Min;
    double          Max;
    int             Root;
    __int64         Prim;
    __int64         Prim1;
    __int64         iRand;
}
DistrAT;
/* table columns descr */
typedef struct _ColDataT {
    int             Type;
    int             Length;
    int             Prec;
    int             Scale;
    int             fPrimKey;
    int             fUnique;
    DistrAT         DistrA;
    char            Name[SMALLBUFF];
}
ColDataT;
ColDataT		*ColData;
/* default fields for each type */
ColDataT        DefCol[TYPE_NUM] = {
    {TYPE_INT,     12,0, 0,0,0,{DISTR_RAND,  INT_MAX/2,  INT_MAX/10,0,  INT_MAX},{0}},
    {TYPE_SMALLINT,6, 0, 0,0,0,{DISTR_RAND, SHRT_MAX/2, SHRT_MAX/10,0, SHRT_MAX},{0}},
    {TYPE_TINYINT, 3, 0, 0,0,0,{DISTR_RAND,UCHAR_MAX/2,UCHAR_MAX/10,0,UCHAR_MAX},{0}},
    {TYPE_CHAR,    5, 6, 0,0,0,{DISTR_RAND,  INT_MAX/2,  INT_MAX/10,0,  INT_MAX},{0}},
    {TYPE_VARCHAR, 5, 6, 0,0,0,{DISTR_RAND,  INT_MAX/2,  INT_MAX/10,0,  INT_MAX},{0}},
    {TYPE_DECIMAL, 20,18,6,0,0,{DISTR_RAND,  INT_MAX/2,  INT_MAX/10,0,  INT_MAX},{0}},
    {TYPE_REAL,    20,18,6,0,0,{DISTR_RAND,  INT_MAX/2,  INT_MAX/10,0,  INT_MAX},{0}},
    {TYPE_FLOAT,   20,18,6,0,0,{DISTR_RAND,  INT_MAX/2,  INT_MAX/10,0,  INT_MAX},{0}},
    {TYPE_DATETIME,TIME_SZ,TIME_SZ,0,0,0,{DISTR_RAND,INT_MAX/2,INT_MAX/10,0,INT_MAX},{0}}
};
__int64			ColMax[TYPE_NUM] = {
	INT_MAX, SHRT_MAX, UCHAR_MAX, I62_1, I62_1, I62_1, INT_MAX, I62_1, I62_1
};
char			*DistrArr[DISTR_NUM] = {
    "random", "ordinal", "normal", "exp(neg)", "poisson", "self-sim", "zipf"
};
char			*TypeArr[TYPE_NUM] = {
    "int", "smallint", "tinyint", "char", "varchar", "decimal", "real", "float",
        "datetime"
};
__int64			Prime[GEN_DECS] = {11, 101, 1009, 10007, 100003, 1000003, 10000019,
	100000007, 2147483647, 10000000019, 100000000003, 1000000000039, 10000000000037,
	100000000000031, 1000000000000037, 10000000000000061, 100000000000000003,
	1000000000000000003
};
int             Root[GEN_DECS] = {2, 7, 26, 59, 242, 568, 1792,
    5649, 16807, 30001, 60010, 180001, 360002,
	1000001, 2000000, 60000008, 120000000,
	360000004
};
#ifdef NO_ODBC
typedef struct tagTIMESTAMP_STRUCT {
    short           year;
    short           month;
    short           day;
    short           hour;
    short           minute;
    short           second;
    int             fraction;
}
TIMESTAMP_STRUCT;
#endif
/* size for bin data */
int             TypeSz[TYPE_NUM] = {
    4, 2, 1, 0, 0, 0, sizeof(float), sizeof(double), 16
        /* sizeof(TIMESTAMP_STRUCT) */
};
/* date constants */
int             DayNum[12] = {
    31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};
int             MonthMin[13] = {
    MONTH_0, MONTH_1, MONTH_2, MONTH_3, MONTH_4, MONTH_5, MONTH_6, MONTH_7,
        MONTH_8, MONTH_9, MONTH_10, MONTH_11, MONTH_12
};
/* for string to value conv */
__int64			Pow95[CHAR95_SZ] = {
    1, 95, 9025, 857375, 81450625, 7737809375, 735091890625, 69833729609375,
        6634204312890625, 630249409724609375
};
char           *MonthName[12] = {
    "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"
};
/* config toks */
char           *InitTok[TOK_NUM] = {
    "Field_Name", "Type", "Length", "Prec", "Scale", "Distr", "Mean", "StdDev",
        "Min", "Max", "Key", "Unique", "Connect", "Table", "Field_Number",
        "Record_Number", "Dest_File", "Dest_Odbc", "DbGen", "Param_h", "Param_a", "Old_Odbc"
};
char           *ArgLine, *FileBuf;
FILE           *File;
int             ColNum, ColNumMax, CurItem, CurSubItem, GranSz, LineSz;
__int64			RowNum;
int             fOldOdbc, fDestFile, fDestOdbc, fTab;
char            Connect[XLARGEBUFF], Table[SMALLBUFF], Config[LARGEBUFF];
#ifndef NO_ODBC
SQLHANDLE       hEnv, hDbc;
SQLHSTMT        hStmt;
SQLINTEGER    **BufLen;
char            Schem[LARGEBUFF], Cat[LARGEBUFF], Quot[2], CatSep[TINYBUFF];
char            BigName[XLARGEBUFF], InsStmt[XLARGEBUFF];
SQLSMALLINT     SqlType[TYPE_NUM] = {
    SQL_INTEGER, SQL_SMALLINT, SQL_TINYINT, SQL_CHAR, SQL_VARCHAR, SQL_DECIMAL, SQL_REAL,
        SQL_FLOAT, SQL_TYPE_TIMESTAMP
};
#endif

#ifndef _CONSOLE
HANDLE          hInst, HelpFl, HelpMap, HelpDc;
HWND            hMain, hConnect, hDestOdbc, hDestFile, hTable, hFldNum, hRowNum, hLv;
HWND            hSBar, hTab, hHelp, hConfig, hTip, hOldOdbc;
/* for input ctrls */
DLGTEMPLATE    *Tmpl;
DLGITEMTEMPLATE *ItemTmpl;
SCROLLINFO      HelpSi;
HBITMAP         hBmpSave, hBmpOpen;
char           *HelpBuf;
int             LvHdHeight, LviHeight, HelpNum, HelpHeight, HelpSz, HelpPos;
/* old wnd procs */
WNDPROC         OldLvProc, OldFieldNumProc, OldInputCtrlProc, OldSBarProc;
/* new field num for pick focus change, lv for return key, satays bar, for highlight link */
int CALLBACK    FieldNumProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK    LvProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK    SBarProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK    InputCtrlProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK    InputDlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
typedef struct _BmiT {
    BITMAPINFOHEADER BmiH;
    RGBQUAD         BmiCol[16];
}
BmiT;
BmiT            Bmi = BMI;
unsigned char   SaveBits[120] = SAVEB, OpenBits[120] = OPENB;
#else
int            *UnqArr, UnqCol;
#endif

/* TrimStr() strip lead and trail blanks */
void            TrimStr(char *s)
{
    char           *z;
    int             i;
    if ((s == NULL) || (*s == '\0'))
        return;
    z = s;
    while (*z && ((*z == ' ') || (*z == '\t')))
        z++;
    if (*z && s != z)
        memmove(s, z, strlen(z) + 1);
    i = strlen(s) - 1;
    while (i >= 0 && (s[i] == ' ' || s[i] == '\t')) {
        s[i] = '\0';
        i--;
    }
}
/* ValidDbl() validate double input */
int             ValidDbl(char *buf)
{
    int             n, i = 0, f = 0, f_point = 0, f_exp = 0, f_expsig = 0;
    TrimStr(buf);
    if (buf == NULL || buf[0] == '\0')
        return 0;
    if (buf[0] == '+' || buf[0] == '-' || buf[0] == '.' || (buf[0] >= '0' && buf[0] <= '9')) {
        n = strlen(buf);
        if (buf[0] == '+' || buf[0] == '-')
            i++;
        while (i < n) {
            if (buf[i] < '0' || buf[i] > '9') {
                if (buf[i] == '.' && f_point == 0 && f_exp == 0 && f_expsig == 0)
                    f_point = 1;
                else if ((buf[i] == 'E' || buf[i] == 'e') && f_exp == 0 && f_expsig == 0)
                    f_exp = 1;
                else if ((buf[i] == '+' || buf[i] == '-') && f_exp == 1 && f_expsig == 0)
                    f_expsig = 1;
                else if (f) {
                    buf[i] = '\0';
                    return 1;
                }
                else
                    return 0;
            }
            f = 1;
            i++;
        }
    }
    return f;
}
/* ValidInt() validate int input */
int             ValidInt(char *buf)
{
    int             n, i = 0, f = 0;
    TrimStr(buf);
    if (buf == NULL || buf[0] == '\0')
        return 0;
    if (buf[0] == '+' || buf[0] == '-' || (buf[0] >= '0' && buf[0] <= '9')) {
        n = min(DEC_I64, strlen(buf));
        if (buf[0] == '+' || buf[0] == '-')
            i++;
        while (i < n) {
            if (buf[i] < '0' || buf[i] > '9') {
                if (f) {
                    buf[i] = '\0';
                    return 1;
                }
                else
                    return 0;
            }
            i++;
            f = 1;
        }
    }
    return f;
}
/* ValidDate() validate date time input (MM/DD/YYYY 12:00AM), set time stamp struct */
int             ValidDate(char *buf, TIMESTAMP_STRUCT * ts)
{
    short           i, hour, mint;
    char           *p, APM[3];
    char            tmpBuf[LARGEBUFF];
    TrimStr(buf);
    if (buf == NULL || buf[0] == '\0')
        return 0;
    memset(ts, 0, sizeof(TIMESTAMP_STRUCT));
    memset(tmpBuf, 0, LARGEBUFF);
    strcpy(tmpBuf, buf);
    if ((p = strtok(tmpBuf, " -./")) == NULL)
        return 0;
    if (!isalnum(*p))
        return 0;
    if (isalpha(*p)) {
        for (i = 0; i < 12; i++)
            if (strncmp(p, MonthName[i], 3) == 0)
                break;
            if (i == 12)
                return 0;
            else
                ts->month = (short) (i + 1);
    }
    else {
        ts->month = (short) atoi(p);
        if (ts->month < 1 || ts->month > 12)
            return 0;
    }
    if ((p = strtok(NULL, " -./")) == NULL)
        return 0;
    ts->day = (short) atoi(p);
    if (ts->day < 1 || ts->day > DayNum[ts->month - 1])
        return 0;
    if ((p = strtok(NULL, " ")) == NULL)
        return 0;
    ts->year = (short) atoi(p);
    if (ts->year > 9999)
        return 0;
    if (ts->year < 100)
        ts->year += 1900;
    if (ts->year < 1753)
        return 0;
    if ((p = strtok(NULL, " ")) == NULL)
        return 1;
    memset(APM, 0, 3);
    sscanf(p, "%2d:%2d%2c", &hour, &mint, APM);
    if (hour < 0 || hour > 23)
        return 0;
    ts->hour = hour;
    if (mint < 0 || mint > 59)
        return 0;
    ts->minute = mint;
    if ((APM[0] == 'p' || APM[0] == 'P') && ts->hour < 12)
        ts->hour += 12;
    return 1;
}
/* TimeToInt() convert date-time to int, 0 if error */
__int64			TimeToInt(char *str)
{
    TIMESTAMP_STRUCT ts;
    if (str == NULL || str[0] == '\0')
        return 0;
    if (!ValidDate(str, &ts))
        return 0;
    return ((__int64) MONTH_12 * (ts.year - 1753) + MonthMin[ts.month - 1]
        + 24 * 60 * (ts.day - 1) + 60 * ts.hour + ts.minute);
}
/* IntToTime() convert int to time str */
void            IntToTime(char *TextBuf, unsigned char *BinBuf, __int64 iVal)
{
    TIMESTAMP_STRUCT	ts;
    short				dYear;
    int					dMonth, dDay, dHour, i;
    memset(&ts, 0, sizeof(TIMESTAMP_STRUCT));
    dYear = (short) (iVal / MONTH_12);
    ts.year = (short) (1753 + dYear);
    dMonth = (int) (iVal - dYear * MONTH_12);
    for (i = 0; i < 12; i++) {
        if (dMonth < MonthMin[i])
            break;
    }
    ts.month = (unsigned short) i;
    dDay = dMonth - MonthMin[i - 1];
    ts.day = (short) (dDay / (24 * 60) + 1);
    dHour = dDay - (ts.day - 1) * (24 * 60);
    ts.hour = (short) (dHour / 60);
    ts.minute = (short) (dHour - ts.hour * 60);
    sprintf(TextBuf, "%02d/%02d/%04d %02d:%02d", ts.month, ts.day, ts.year, ts.hour, ts.minute);
    if (BinBuf)
        memcpy(BinBuf, &ts, sizeof(TIMESTAMP_STRUCT));
}
/* IntToStr() convert int to str */
void			IntToStr(char *str, __int64 iVal, int length)
{
    int				i = 0, n = CHAR95_SZ - 1;
    if (iVal == 0)
        str[0] = ' ';
    else {
        while (n > 0 && iVal / Pow95[n] == 0)
            n--;
        while (n - i >= 0 && i < length) {
            str[i] = (unsigned char) (iVal / Pow95[n - i]);
            iVal -= str[i] * Pow95[n - i];
            str[i] += 32;
			i++;
        }
    }
}
/* StrToInt() convert str to int */
__int64			StrToInt(char *str)
{
    int				i, n;
    __int64			ret = 0;
    if (str == NULL || str[0] == '\0')
        return 0;
    n = strlen(str);
    if (n > CHAR95_SZ)
        return I62_1;
    for (i = 0; i < n; i++)
        ret += (__int64) (str[n - 1 - i] - 32) * Pow95[i];
    return ret;
}
/* EnableCol() enable proper fields */
int             EnableCol(int Type, int Distr, int i)
{
    if (((Type == TYPE_CHAR || Type == TYPE_VARCHAR) && (i == COL_PREC || i == COL_SCALE))
        || (Type == TYPE_DECIMAL && i == COL_LENGTH)
        || ((Type == TYPE_TINYINT || Type == TYPE_SMALLINT || Type == TYPE_INT
        || Type == TYPE_DATETIME || Type == TYPE_REAL || Type == TYPE_FLOAT)
        && (i == COL_PREC || i == COL_SCALE || i == COL_LENGTH))
        || ((Distr == DISTR_RAND || Distr == DISTR_ORD) && (i == COL_MEAN || i == COL_STDDEV))
        || ((Distr == DISTR_EXPN || Distr == DISTR_POIS || Distr == DISTR_SSIM
        || Distr == DISTR_ZIPF) && i == COL_MEAN))
        return 0;
    return 1;
}
/* SetValidCol() - valid and set Col */
void            SetValidCol(char *buf, ColDataT * Col, int iSubItem)
{
    char            tmpBuf[XLARGEBUFF];
    int             i;
    if (!EnableCol(Col->Type, Col->DistrA.Distr, iSubItem))
        return;
    switch (iSubItem) {
    case COL_NAME:
        strcpy(Col->Name, buf);
        break;
    case COL_TYPE:
        if (Col->Type != *(int *) buf) {
            i = *(int *) buf;
            strcpy(tmpBuf, Col->Name);
            memcpy(Col, &DefCol[i], sizeof(ColDataT));
            strcpy(Col->Name, tmpBuf);
            Col->Type = i;
        }
        break;
    case COL_LENGTH:
        Col->Length = atoi(buf);
        if (Col->Type == TYPE_CHAR || Col->Type == TYPE_VARCHAR)
            Col->Prec = Col->Length + 1;
        break;
    case COL_PREC:
        Col->Prec = atoi(buf);
        if (Col->Type == TYPE_DECIMAL) {
            Col->Length = Col->Prec + 2;
            Col->Scale = (Col->Scale <= Col->Prec ? Col->Scale : Col->Prec);
        }
        break;
    case COL_SCALE:
        Col->Scale = atoi(buf);
        if (Col->Type == TYPE_DECIMAL)
            Col->Scale = (Col->Scale <= Col->Prec ? Col->Scale : Col->Prec);
        break;
    case COL_DISTR:
        Col->DistrA.Distr = *(int *) buf;
        break;
    case COL_STDDEV:
        Col->DistrA.Deviat = (ValidDbl(buf) ? atof(buf) : 0);
        break;
    case COL_MEAN:
		Col->DistrA.Mean = STR_TO_VAL(Col->Type, buf);
		break;
    case COL_MIN:
        Col->DistrA.Min = STR_TO_VAL(Col->Type, buf);
		break;
    case COL_MAX:
        Col->DistrA.Max = STR_TO_VAL(Col->Type, buf);
		break;
    case COL_KEY:
        if (!Col->fPrimKey) {
            /* global scan! */
            for (i = 0; i < ColNum; i++)
                ColData[i].fPrimKey = 0;
        }
        Col->fUnique = 0;
        Col->fPrimKey = !(*(int *) buf);
        break;
    case COL_UNIQUE:
        Col->fUnique = !(*(int *) buf);
        Col->fPrimKey = 0;
        break;
    }
    if ((iSubItem == COL_MIN || iSubItem == COL_MAX) && Col->DistrA.Min > Col->DistrA.Max) {
        Col->DistrA.Min = 0;
		Col->DistrA.Max = (double) ColMax[Col->Type];
    }
}
/* print message and exit if so */
void            MsgPrint(int fExit, char *s1,...)
{
    va_list         par;
    char           *p = s1, buf[XLARGEBUFF];
    strcpy(buf, s1);
    va_start(par, s1);
    while ((p = va_arg(par, char *)) != NULL) {
        if (strlen(p) + strlen(buf) >= XLARGEBUFF)
            break;
        strcat(buf, p);
    }
    va_end(par);
#ifndef _CONSOLE
    MessageBox(hMain, buf, InitTok[TOK_DBGEN], MB_OK);
#else
    printf("%s\n", buf);
#endif
    if (fExit)
        exit(EXIT_FAILURE);
}
/* SrchArr()  search str array */
int             SrchArr(char **arr, char *str, int n)
{
    int             i;
    for (i = 0; i < n; i++)
        if (strcmp(arr[i], str) == 0)
            break;
        if (i == n)
            i = -1;
        return i;
}
/* RawPush() add data to head block to resized array */
void            RawPush(char **h, int *cur, int *n, void *v, int sz)
{
    if (*cur + 1 > *n) {
        (*n) += 16;
        if ((*h = (char *) realloc(*h, *n * sz)) == NULL)
            MsgPrint(1, "Unable to realloc", NULL);
    }
    memcpy(*h + *cur * sz, v, sz);
    (*cur)++;
}
/* TokHash() hash toks casting to int */
int             TokHash(char *b)
{
    int             i;
    for (i = 0; i < TOK_NUM; i++) {
        switch (i) {
        case TOK_NAME:
        case TOK_FLDNUM:
            if (*(int *) b == *(int *) InitTok[i]
                && *(int *) (b + 4) == *(int *) (InitTok[i] + 4))
                return i;
            break;
        case TOK_H:
        case TOK_A:
        case TOK_DESTFILE:
        case TOK_DESTODBC:
            if (*(int *) b == *(int *) InitTok[i]
                && *(short *) (b + 4) == *(short *) (InitTok[i] + 4))
                return i;
            break;
        case TOK_MIN:
        case TOK_MAX:
            if (*(short *) b == *(short *) InitTok[i])
                return i;
            break;
        default:
            if (*(int *) b == *(int *) InitTok[i])
                return i;
        }
    }
    return TOK_NUM;
}
/* SetFielName()*/
void            SetFielName(char *buf)
{
    int             i, j = 1;
    while (1) {
        sprintf(buf, "F%d", j);
        for (i = 0; i < ColNum - 1; i++)
            if (!strcmp(ColData[i].Name, buf))
                break;
            if (ColNum > 1 && i < ColNum - 1)
                j++;
            else
                break;
    }
}
/* AddM() i+j mod m */
__int64			AddM(__int64 i, __int64 j, __int64 m)
{
    __int64			k;
    if (i > I62_1 - j)
        k = (i > j ? i - m + j : j - m + i);
    else
        k = i + j;
    if (k > m)
        k -= m;
    return k;
}
/* MulM() (xy)mod m */
__int64			MulM(__int64 x, __int64 y, __int64 m)
{
    __int64			i, j, k, x0, y0, x1, y1;
    if (y != 0 && x > I62_1 / y) {
        x0 = x & I31_1;
        x1 = (unsigned __int64) x >> 31;
        y0 = y & I31_1;
        y1 = (unsigned __int64) y >> 31;
        i = x0 * y1 % m;
        j = x1 * y0 % m;
        k = AddM(i, j, m);
        i = MulM(k, I31, m);
        j = x0 * y0 % m;
        k = AddM(i, j, m);
        i = x1 * y1 % m;
        j = MulM(i, I62 % m, m);
        i = AddM(j, k, m);
        return i % m;
    }
    else
        return x * y % m;
}
/* InitCol() init wnd data from file named in CmdLine */
int             InitCol(char *CmdLine)
{
    FILE           *fh;
    int             i, m, len;
    char           *p, *p1, buf[XLARGEBUFF], buf0[XLARGEBUFF];
    sprintf(Connect, CONN_MS);
    strcpy(Table, InitTok[TOK_DBGEN]);
    RowNum = 1;
    if (CmdLine == NULL || CmdLine[0] == '\0' || (fh = fopen(CmdLine, "r")) == NULL) {
        fDestFile = 1;
        fDestOdbc = 1;
        RawPush((char **) &ColData, &ColNum, &ColNumMax, &DefCol[TYPE_INT], sizeof(ColDataT));
        strcpy(ColData[ColNum - 1].Name, "F1");
        return 0;
    }
    else {
        while (fgets(buf, XLARGEBUFF, fh)) {
            p = buf + strlen(buf) - 1;
            if (*p == '\n' || *p == '\r')
                *p = '\0';
            len = strlen(buf);
            p = buf;
            while (*p == ' ' || *p == '\t')
                p++;
            /* interval cmp - col descr toks should be first */
            if (TokHash(p) < TOK_CONNECT) {
                RawPush((char **) &ColData, &ColNum, &ColNumMax, &DefCol[TYPE_INT],
                    sizeof(ColDataT));
                SetFielName(ColData[ColNum - 1].Name);
            }
            while (p - buf < len) {
                while (*p == ' ' || *p == '\t')
                    p++;
                if ((m = TokHash(p)) == TOK_NUM)
                    break;
                while (*p != '\0' && *p != '=')
                    p++;
                if (*p == '\0' || p[1] == '\0')
                    break;
                p1 = ++p;
                while (!(*p1 == '\0' || (*p1 == ' ' && TokHash(p1 + 1) != TOK_NUM)))
                    p1++;
                if (*p1 != '\0')
                    *p1 = '\0';
                strcpy(buf0, p);
                TrimStr(buf0);
                switch (m) {
                case TOK_CONNECT:
                    if (strlen(buf0) < LARGEBUFF)
                        strcpy(Connect, buf0);
                    break;
                case TOK_TABLE:
                    if (strlen(buf0) < SMALLBUFF)
                        strcpy(Table, buf0);
                    break;
                case TOK_ROWNUM:
                    if (ValidInt(buf0) && atoi(buf0) > 0)
                        RowNum = atoi(buf0);
                    break;
                case TOK_DESTFILE:
                    fDestFile = (*(short *) buf0 == *(short *) "On") ? 1 : 0;
                    break;
                case TOK_DESTODBC:
                    fDestOdbc = (*(short *) buf0 == *(short *) "On") ? 1 : 0;
                    break;
                case TOK_NAME:
                    if (strlen(buf0) < SMALLBUFF)
                        SetValidCol(buf0, &ColData[ColNum - 1], m);
                    break;
                case TOK_TYPE:
                    if ((i = SrchArr(TypeArr, buf0, TYPE_NUM)) != -1) {
                        *(int *) buf0 = i;
                        SetValidCol(buf0, &ColData[ColNum - 1], m);
                    }
                    break;
                case TOK_DISTR:
                    if ((i = SrchArr(DistrArr, buf0, DISTR_NUM)) != -1) {
                        *(int *) buf0 = i;
                        SetValidCol(buf0, &ColData[ColNum - 1], m);
                    }
                    break;
                case TOK_LENGTH:
                case TOK_PREC:
                case TOK_SCALE:
                case TOK_MEAN:
                case TOK_STDDEV:
                case TOK_MIN:
                case TOK_MAX:
                case TOK_A:
                case TOK_H:
                    if (m == TOK_A || m == TOK_H)
                        m = TOK_STDDEV;
                    SetValidCol(buf0, &ColData[ColNum - 1], m);
                    break;
                    /* ColNum should be avail globaly */
                case TOK_KEY:
                case TOK_UNIQUE:
                    if (*(short *) buf0 == *(short *) "On") {
                        *(int *) buf0 = 1;
                        SetValidCol(buf0, &ColData[ColNum - 1], m);
                    }
                    break;
                case TOK_OLDODBC:
                    fOldOdbc = (*(short *) buf0 == *(short *) "On") ? 1 : 0;
                    break;
                }
                p = p1 + 1;
            }
        }
        fclose(fh);
    }
    return 1;
}
void			ValToStr(char *buf, int type, double Val)
{
	switch (type) {
	case TYPE_CHAR:
	case TYPE_VARCHAR:
		IntToStr(buf, (__int64) Val, SMALLBUFF);
		break;
	case TYPE_DATETIME:
		IntToTime(buf, NULL, (__int64) Val);
		break;
	case TYPE_INT:
	case TYPE_SMALLINT:
	case TYPE_TINYINT:
		_i64toa((__int64) Val, buf, 10);
		break;
    default:
        sprintf(buf, "%g", Val);
        break;
	}
}
/* GetColStr get text from Col subitem */
void            GetColStr(ColDataT * Col, int iSubItem, char *buf, int bufSz)
{
    memset(buf, 0, bufSz);
    if (!EnableCol(Col->Type, Col->DistrA.Distr, iSubItem)) {
        strcpy(buf, "...");
        return;
    }
    switch (iSubItem) {
    case COL_NAME:
        strcpy(buf, Col->Name);
        break;
    case COL_TYPE:
        strcpy(buf, TypeArr[Col->Type]);
        break;
    case COL_LENGTH:
        sprintf(buf, "%d", Col->Length);
        break;
    case COL_PREC:
        sprintf(buf, "%d", Col->Prec);
        break;
    case COL_SCALE:
        sprintf(buf, "%d", Col->Scale);
        break;
    case COL_DISTR:
        strcpy(buf, DistrArr[Col->DistrA.Distr]);
        break;
    case COL_STDDEV:
        sprintf(buf, "%g", Col->DistrA.Deviat);
        break;
    case COL_MEAN:
        ValToStr(buf, Col->Type, Col->DistrA.Mean);
        break;
    case COL_MIN:
		ValToStr(buf, Col->Type, Col->DistrA.Min);
        break;
    case COL_MAX:
		ValToStr(buf, Col->Type, Col->DistrA.Max);
		break;
    case COL_KEY:
        if (Col->fPrimKey)
            strcpy(buf, "On");
        break;
    case COL_UNIQUE:
        if (Col->fUnique)
            strcpy(buf, "On");
        break;
    }
}
/* SaveConf() save config settings */
int             SaveConf(char *name)
{
    char            buf0[SMALLBUFF];
    FILE           *fh;
    int             i, j, k;
    time_t          t;
    if ((fh = fopen(name, "w")) == NULL)
        return 0;
    time(&t);
    fprintf(fh, "Dbgen=%s\n", asctime(localtime(&t)));
    if (Connect[0] != 0)
        fprintf(fh, "%s=%s\n", InitTok[TOK_CONNECT], Connect);
    if (Table[0] != 0)
        fprintf(fh, "%s=%s\n", InitTok[TOK_TABLE], Table);
    fprintf(fh, "%s=%d\n", InitTok[TOK_ROWNUM], RowNum);
    if (fDestOdbc)
        fprintf(fh, "%s=On\n", InitTok[TOK_DESTODBC]);
    if (fDestFile)
        fprintf(fh, "%s=On\n", InitTok[TOK_DESTFILE]);
    if (fOldOdbc)
        fprintf(fh, "%s=On\n", InitTok[TOK_OLDODBC]);
    for (i = 0; i < ColNum; i++) {
        for (j = 0; j < COL_NUM; j++) {
            if (EnableCol(ColData[i].Type, ColData[i].DistrA.Distr, j)) {
                GetColStr(&ColData[i], j, buf0, SMALLBUFF);
                if (j != TOK_STDDEV || (ColData[i].DistrA.Distr != DISTR_SSIM
                    && ColData[i].DistrA.Distr != DISTR_ZIPF))
                    k = j;
                else {
                    if (ColData[i].DistrA.Distr == DISTR_SSIM)
                        k = TOK_H;
                    else
                        k = TOK_A;
                }
                if (buf0[0])
                    fprintf(fh, "%s=%s ", InitTok[k], buf0);
            }
        }
        fprintf(fh, "\n");
    }
    if (fclose(fh) == EOF)
        return 0;
    return 1;
}
/* Gauss() */
__int64			Gauss(DistrAT * distr)
{
    int				i;
    double			ans = 0;
    for (i = 0; i < 12; i++) {
        ans += distr->iRand / (double) distr->Prim1 - 0.5;
        distr->iRand = MulM(distr->iRand, distr->Root, distr->Prim);
    }
    return (__int64) (distr->Mean + distr->Deviat * ans);
}
/* ExpNeg()*/
__int64			ExpNeg(DistrAT * distr)
{
    __int64			ret;
    ret = (__int64) (- distr->Deviat * log(distr->iRand / (double) distr->Prim1));
    distr->iRand = MulM(distr->iRand, distr->Root, distr->Prim);
    return ret;
}
/* Poisson() */
__int64			Poisson(DistrAT * distr)
{
    __int64			i = 0;
    double			c, p = 1;
    c = pow(2.718282, - distr->Deviat);
    if (c == 0)
        return 0;
    while (p >= c) {
        p = p * (distr->iRand / (double) distr->Prim1);
        i++;
		distr->iRand = MulM(distr->iRand, distr->Root, distr->Prim);
    }
    return (i - 1);
}
/* SelfSim() */
__int64			SelfSim(DistrAT * distr)
{
    __int64			ret;
    ret = (__int64) (1 + distr->iRand * pow(distr->iRand / (double) distr->Prim1,
        log(distr->Deviat) / log(1 - distr->Deviat)));
    distr->iRand = MulM(distr->iRand, distr->Root, distr->Prim);
    return ret;
}
/* zeta() */
double			zeta(__int64 n, double theta)
{
    int				i;
    double			ret = 0.0;
    for (i = 1; i < n; i++)
        ret += pow(i, -theta);
    return ret;
}
/* Zipfr() */
__int64			Zipf(DistrAT * distr)
{
    __int64			r, ret;
    double			alpha, zetan, eta, uz, u;
    r = distr->iRand;
    distr->iRand = MulM(distr->iRand, distr->Root, distr->Prim);
    alpha = 1 / (1 - distr->Deviat);
    u = r / (double) distr->Prim1;
    zetan = zeta(r, distr->Deviat);
    uz = u * zetan;
    if (uz < 1)
        return 1;
    if (uz < 1 + pow(0.5, distr->Deviat))
        return 2;
    eta = (1 - pow(2.0 / r, 1 - distr->Deviat)) * (1 - zeta(2, distr->Deviat) / zetan);
    ret = (__int64) (1 + r * pow(eta * u - eta + 1, alpha));
    return ret;
}
/* FillBuf() fill buf */
void			FillBuf(char *TextBuf, unsigned char *BinBuf, __int64 iVal, int ind)
{
    int				n, rAlign;
    double			dVal;
    if (ColData[ind].DistrA.Distr == DISTR_GAUS || ColData[ind].DistrA.Distr == DISTR_EXPN)
        dVal = ColData[ind].DistrA.Min + (ColData[ind].DistrA.Max
        - ColData[ind].DistrA.Min) / ColData[ind].DistrA.Prim1 * iVal;
    else {
        iVal += (__int64) ColData[ind].DistrA.Min;
        dVal = (double) iVal;
    }
    switch (ColData[ind].Type) {
    case TYPE_CHAR:
    case TYPE_VARCHAR:
        memset(TextBuf, 0, ColData[ind].Length);
        if (ColData[ind].DistrA.Distr == DISTR_RAND || ColData[ind].DistrA.Distr == DISTR_ORD)
            IntToStr(TextBuf, iVal, ColData[ind].Length);
        else
            IntToStr(TextBuf, (__int64) dVal, ColData[ind].Length);
        if (ColData[ind].Type == TYPE_CHAR) {
            rAlign = min(CHAR95_SZ, ColData[ind].Length);
            n = (int) strlen(TextBuf);
            memmove(TextBuf + rAlign - n, TextBuf, n);
            memset(TextBuf, ' ', rAlign - n);
		}
		n = (int) strlen(TextBuf);
        if (ColData[ind].Length > n)
			memset(TextBuf + n, '_', ColData[ind].Length - n);
        break;
    case TYPE_DECIMAL:
    case TYPE_REAL:
    case TYPE_FLOAT:
        sprintf(TextBuf, "%*.*f", ColData[ind].Prec + 2, ColData[ind].Scale, dVal);
        if (ColData[ind].Type == TYPE_REAL)
            *(float *) BinBuf = (float) dVal;
        else if (ColData[ind].Type == TYPE_FLOAT)
            *(double *) BinBuf = dVal;
        break;
    case TYPE_DATETIME:
        if (ColData[ind].DistrA.Distr == DISTR_RAND || ColData[ind].DistrA.Distr == DISTR_ORD)
            IntToTime(TextBuf, BinBuf, iVal);
        else
            IntToTime(TextBuf, BinBuf, (__int64) dVal);
        break;
    case TYPE_INT:
    case TYPE_SMALLINT:
    case TYPE_TINYINT:
        if (ColData[ind].DistrA.Distr != DISTR_RAND && ColData[ind].DistrA.Distr != DISTR_ORD)
            iVal = (__int64) dVal;
        sprintf(TextBuf, "%*d", ColData[ind].Length, (int) iVal);
        memcpy(BinBuf, &iVal, TypeSz[ColData[ind].Type]);
        break;
    }
}
/* SetDistr() main deviation evaluation proc */
void			SetDistr(char *TextBuf, unsigned char *BinBuf, int ind, __int64 CurGran)
{
    __int64			iVal, iRg;
    int				i;
    if (CurGran == 0) {
        ColData[ind].DistrA.iRand = ColData[ind].DistrA.Root;
        iVal = -1;
    }
    else
        iVal = GRAN_SZ * CurGran;
    if (ColData[ind].DistrA.Distr == DISTR_GAUS || ColData[ind].DistrA.Distr == DISTR_EXPN)
        iRg = ColData[ind].DistrA.Prim1;
    else
        iRg = (__int64) (ColData[ind].DistrA.Max - ColData[ind].DistrA.Min);
    for (i = 0; i < GranSz; i++) {
        do {
            switch (ColData[ind].DistrA.Distr) {
            case DISTR_ORD:
                iVal++;
                if (iVal > iRg)
                    iVal = 0;
                break;
            case DISTR_RAND:
                iVal = ColData[ind].DistrA.iRand;
				ColData[ind].DistrA.iRand = MulM(ColData[ind].DistrA.iRand,
					ColData[ind].DistrA.Root, ColData[ind].DistrA.Prim);
                break;
            case DISTR_GAUS:
                iVal = Gauss(&ColData[ind].DistrA);
                break;
            case DISTR_EXPN:
                iVal = ExpNeg(&ColData[ind].DistrA);
                break;
            case DISTR_POIS:
                iVal = Poisson(&ColData[ind].DistrA);
                break;
            case DISTR_SSIM:
                iVal = SelfSim(&ColData[ind].DistrA);
                break;
            case DISTR_ZIPF:
                iVal = Zipf(&ColData[ind].DistrA);
                break;
            }
        }
        while (iVal > iRg || iVal < 0);
        FillBuf(TextBuf, BinBuf, iVal, ind);
        TextBuf += ColData[ind].Length + 1;
        BinBuf += TypeSz[ColData[ind].Type];
#ifdef _CONSOLE
        if (UnqCol == ind)
            UnqArr[CurGran * GRAN_SZ + i] = iVal;
#endif
    }
}
/* TextWrite() write into file */
void			TextWrite(char **TextBuf, __int64 CurGran, __int64 GranNum)
{
    __int64			i;
    int				j;
    char			buf[LARGEBUFF], *p = NULL;
    if (CurGran == 0) {
        if (Table != NULL && Table[0] != '\0')
            strcpy(Table, InitTok[TOK_DBGEN]);
        sprintf(buf, "%s.txt", Table);
        if ((File = fopen(buf, "wb")) == NULL)
            MsgPrint(1, "Unable to open", NULL);
        LineSz = 0;
        for (i = 0; i < ColNum; i++)
            LineSz += ColData[i].Length + 1;
        LineSz++;
        if ((FileBuf = (char *) malloc(LineSz * GRAN_SZ)) == NULL)
            MsgPrint(1, "Unable to malloc", NULL);
    }
    p = FileBuf;
    for (i = 0; i < GranSz; i++) {
        for (j = 0; j < ColNum; j++) {
            strcpy(p, TextBuf[j] + i * (ColData[j].Length + 1));
            p[ColData[j].Length] = ',';
            p += ColData[j].Length + 1;
        }
        *(p - 1) = '\r';
        *p = '\n';
        p++;
    }
    if (fwrite(FileBuf, LineSz, GranSz, File) != (size_t) GranSz)
        MsgPrint(1, "Unable to write", NULL);
    if (CurGran == GranNum - 1) {
        free(FileBuf);
        if (fclose(File) == EOF)
            MsgPrint(1, "Unable to close", NULL);
    }
}
#ifndef NO_ODBC
/* DisplayError() - from ODBCSDK SAMPLES QUERYDEMO query.c */
void			DisplayError(short hdlType, SQLHANDLE hdl)
{
    char			state[6], msg[SQL_MAX_MESSAGE_LENGTH];
    char			buf[XLARGEBUFF], DispBuf[XLARGEBUFF] = {'\0'};
    short			len, n = 1;
    UDWORD			native;
    SQLRETURN rc = SQL_SUCCESS;
    while ((rc = SQLGetDiagRec(hdlType, hdl, n++, (SQLCHAR *) state, (SQLINTEGER *) & native,
        (SQLCHAR *) msg, SQL_MAX_MESSAGE_LENGTH, &len)) != SQL_NO_DATA) {
        if (rc == SQL_ERROR || rc == SQL_INVALID_HANDLE)
            break;
        if (58 + strlen(state) + strlen(msg) >= XLARGEBUFF)
            break;
        sprintf(buf, "SQL Error State:%s, Native Error Code: %6x, ODBC Error: %s\n",
            state, native, msg);
        if (strlen(DispBuf) + strlen(buf) >= XLARGEBUFF)
            break;
        strcat(DispBuf, buf);
    }
    MsgPrint(0, DispBuf, NULL);
}
/* OdbcErr() - check error retcode  */
int				OdbcErr(RETCODE rc, int fFatal)
{
    short			hdlType = 0;
    SQLHANDLE		hdl = NULL;
    if (rc == SQL_SUCCESS || rc == SQL_SUCCESS_WITH_INFO)
        return 0;
    else if (fFatal) {
        if (hStmt != SQL_NULL_HSTMT) {
            hdl = hStmt;
            hdlType = SQL_HANDLE_STMT;
        }
        else if (hDbc != SQL_NULL_HANDLE) {
            hdl = hDbc;
            hdlType = SQL_HANDLE_DBC;
        }
        else if (hEnv != SQL_NULL_HANDLE) {
            hdl = hEnv;
            hdlType = SQL_HANDLE_ENV;
        }
        DisplayError(hdlType, hdl);
        SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
        SQLDisconnect(hDbc);
        SQLFreeHandle(SQL_HANDLE_DBC, hDbc);
        SQLFreeHandle(SQL_HANDLE_ENV, hEnv);
        hEnv = SQL_NULL_HANDLE;
        hDbc = SQL_NULL_HANDLE;
        hStmt = SQL_NULL_HSTMT;
    }
    return 1;
}
/* InitConnect() - init connection */
int				InitConnect(void)
{
    short			c;
    char			buf[XLARGEBUFF];
    if (OdbcErr(SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv), 1))
        return 0;
    if (fOldOdbc && OdbcErr(SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION,
        (SQLPOINTER) SQL_OV_ODBC2, 0), 1))
        return 0;
    else if (OdbcErr(SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION,
        (SQLPOINTER) SQL_OV_ODBC3, 0), 1))
        return 0;
    if (OdbcErr(SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hDbc), 1))
        return 0;
    if (OdbcErr(SQLDriverConnect(hDbc, NULL, (SQLCHAR *) Connect, (short) (strlen(Connect) + 1),
        (UCHAR *) buf, (UWORD) XLARGEBUFF, &c, SQL_DRIVER_NOPROMPT), 1))
        return 0;
    if (OdbcErr(SQLAllocHandle(SQL_HANDLE_STMT, hDbc, &hStmt), 1))
        return 0;
    return 1;
}
/* ClearStmt() - clear statement */
int			ClearStmt(void)
{
    if (OdbcErr(SQLFreeStmt(hStmt, SQL_RESET_PARAMS), 1))
        return 0;
    if (OdbcErr(SQLFreeStmt(hStmt, SQL_UNBIND), 1))
        return 0;
    if (OdbcErr(SQLFreeStmt(hStmt, SQL_CLOSE), 1))
        return 0;
    return 1;
}
/* SetBigName() - set schem, qualifier, quote char for table */
int			SetBigName(void)
{
    SQLINTEGER		ci, f;
    short			c, f0;
    char buf[LARGEBUFF];
    if (OdbcErr(SQLGetInfo(hDbc, SQL_QUALIFIER_USAGE, &f, sizeof(f), &c), 1))
        return 0;
    if (f & SQL_QU_TABLE_DEFINITION
        && OdbcErr(SQLGetConnectAttr(hDbc, SQL_CURRENT_QUALIFIER, Cat, LARGEBUFF, &ci), 1))
        return 0;
    if (OdbcErr(SQLGetInfo(hDbc, SQL_QUALIFIER_NAME_SEPARATOR, CatSep, TINYBUFF, &c), 1))
        return 0;
    if (c == 0)
        CatSep[0] = '\0';
    if (OdbcErr(SQLGetInfo(hDbc, SQL_OWNER_USAGE, &f, sizeof(f), &c), 1))
        return 0;
    if (f & SQL_OU_TABLE_DEFINITION
        && OdbcErr(SQLGetInfo(hDbc, SQL_USER_NAME, Schem, LARGEBUFF, &c), 1))
        return 0;
    if (OdbcErr(SQLGetInfo(hDbc, SQL_IDENTIFIER_QUOTE_CHAR, Quot, 2, &c), 1))
        return 0;
    if (Quot[0] == ' ' || c > 1)
        Quot[0] = '\0';
    if (OdbcErr(SQLGetInfo(hDbc, SQL_QUALIFIER_LOCATION, &f0, sizeof(f0), &c), 1))
        return 0;
    memset(BigName, 0, XLARGEBUFF);
    if (Schem[0] != '\0')
        sprintf(BigName, "%s%s%s.", Quot, Schem, Quot);
    sprintf(buf, "%s%s%s", Quot, Table, Quot);
    strcat(BigName, buf);
    if (Cat[0] != '\0') {
        if (f0 == SQL_QL_END) {
            sprintf(buf, "%s%s%s%s", CatSep, Quot, Cat, Quot);
            strcat(BigName, buf);
        }
        else {
            sprintf(buf, "%s%s%s%s", Quot, Cat, Quot, CatSep);
            memmove(BigName + strlen(buf), BigName, strlen(BigName) + 1);
            memcpy(BigName, buf, strlen(buf));
        }
    }
    return 1;
}
/* DropCoinTable() - drop table if name is similar to demanded */
int				DropCoinTable(void)
{
    SQLINTEGER		c;
    char			buf[LARGEBUFF], srchName[LARGEBUFF] = {'\0'};
    if (!ClearStmt())
        return 0;
    if (OdbcErr(SQLTables(hStmt, (SQLCHAR *) Cat, SQL_NTS, (SQLCHAR *) Schem, SQL_NTS,
        (SQLCHAR *) Table, SQL_NTS, NULL, 0), 1))
        return 0;
    if (SQLFetch(hStmt) == SQL_ERROR)
        return 0;
    SQLGetData(hStmt, 3, SQL_CHAR, srchName, LARGEBUFF, &c);
    if (!ClearStmt())
        return 0;
    if (strcmp(srchName, Table) == 0) {
        sprintf(buf, "drop table %s", BigName);
        if (OdbcErr(SQLExecDirect(hStmt, (SQLCHAR *) buf, SQL_NTS), 1))
            return 0;
    }
    return 1;
}
/* SetCreateStmt() set create stmt */
int				SetCreateStmt(char **pBuf)
{
    int				i, sz = XLARGEBUFF;
    char			buf0[TINYBUFF], buf[XLARGEBUFF];
    *pBuf = NULL;
    if ((*pBuf = (char *) malloc(sz)) == NULL)
        MsgPrint(1, "Unable to malloc", NULL);
    sprintf(*pBuf, "create table %s (", BigName);
    for (i = 0; i < ColNum; i++) {
        sprintf(buf, "%s %s", ColData[i].Name, TypeArr[ColData[i].Type]);
        if (ColData[i].Type == TYPE_CHAR || ColData[i].Type == TYPE_VARCHAR
            || ColData[i].Type == TYPE_DECIMAL) {
            sprintf(buf0, "(%d", ColData[i].Prec);
            strcat(buf, buf0);
            if (ColData[i].Type == TYPE_DECIMAL) {
                sprintf(buf0, ",%d", ColData[i].Scale);
                strcat(buf, buf0);
            }
            strcat(buf, ")");
        }
        strcat(buf, " not NULL");
        if (ColData[i].fUnique) {
            strcat(buf, " ");
            strcat(buf, "unique");
        }
        if (ColData[i].fPrimKey) {
            strcat(buf, " ");
            strcat(buf, "primary key");
        }
        if (i != ColNum - 1)
            strcat(buf, ",");
        else
            strcat(buf, ")");
        if ((int) strlen(buf) + (int) strlen(*pBuf) >= sz) {
            sz += XLARGEBUFF;
            if ((*pBuf = (char *) realloc(*pBuf, sz)) == NULL)
                MsgPrint(1, "Unable to malloc", NULL);
        }
        strcat(*pBuf, buf);
    }
    return 1;
}
/* OdbcWrite() create and populate database table */
int				OdbcWrite(char **TextBuf, unsigned char **BinBuf, __int64 CurGran, __int64 GranNum)
{
    int				i;
    __int64			j;
    char			*pBuf;
    if (CurGran == 0) {
        hEnv = SQL_NULL_HANDLE;
        hDbc = SQL_NULL_HANDLE;
        hStmt = SQL_NULL_HSTMT;
        if (!InitConnect())
            return 0;
        if (!SetBigName())
            return 0;
        if (!DropCoinTable())
            return 0;
        if (!SetCreateStmt(&pBuf))
            return 0;
        if (OdbcErr(SQLExecDirect(hStmt, (SQLCHAR *) pBuf, SQL_NTS), 1))
            return 0;
        free(pBuf);
        sprintf(InsStmt, "insert into %s values (", BigName);
        if (!ClearStmt())
            return 0;
        if (!fOldOdbc && OdbcErr(SQLSetStmtAttr(hStmt, SQL_ATTR_PARAMSET_SIZE,
            (SQLPOINTER) GranSz, 0), 1))
            return 0;
        if ((BufLen = (SQLINTEGER **) malloc(ColNum * sizeof(SQLINTEGER *))) == NULL)
            MsgPrint(1, "Unable to malloc", NULL);
        memset(BufLen, 0, ColNum * sizeof(SQLINTEGER *));
        for (i = 0; i < ColNum; i++) {
            strcat(InsStmt, "?");
            if (i != ColNum - 1)
                strcat(InsStmt, ",");
            else
                strcat(InsStmt, ")");
            if ((BufLen[i] = (SQLINTEGER *) malloc(GranSz * sizeof(SQLINTEGER))) == NULL)
                MsgPrint(1, "Unable to malloc", NULL);
            memset(BufLen[i], 0, GranSz * sizeof(SQLINTEGER));
            if (CHAR_LIKE(ColData[i].Type))
                for (j = 0; j < GranSz; j++)
                    BufLen[i][j] = SQL_NTS;
                else
                    for (j = 0; j < GranSz; j++)
                        BufLen[i][j] = TypeSz[ColData[i].Type];
                    if (!fOldOdbc && OdbcErr(SQLBindParameter(hStmt,
                        (SQLUSMALLINT) (i + 1),
                        SQL_PARAM_INPUT,
                        SQL_DEFAULT, SqlType[ColData[i].Type],
                        ColData[i].Type == TYPE_DECIMAL ? ColData[i].Prec
                        : ColData[i].Length,
                        ColData[i].Type == TYPE_DECIMAL ? ColData[i].Scale : 0,
                        CHAR_LIKE(ColData[i].Type) ? (SQLPOINTER) TextBuf[i]
                        : (SQLPOINTER) BinBuf[i],
                        CHAR_LIKE(ColData[i].Type) ? ColData[i].Length + 1
                        : TypeSz[ColData[i].Type],
                        BufLen[i]), 1))
                        return 0;
        }
    }
    if (!fOldOdbc) {
        if (CurGran == GranNum - 1 && RowNum / GRAN_SZ
            && RowNum % GRAN_SZ && OdbcErr(SQLSetStmtAttr(hStmt, SQL_ATTR_PARAMSET_SIZE,
            (SQLPOINTER) GranSz, 0), 1))
            return 0;
        if (OdbcErr(SQLExecDirect(hStmt, (SQLCHAR *) InsStmt, SQL_NTS), 1))
            return 0;
    }
    else {
        for (j = 0; j < GranSz; j++) {
            if (!ClearStmt())
                return 0;
            for (i = 0; i < ColNum; i++)
                if (OdbcErr(SQLBindParameter(hStmt,
                    (SQLUSMALLINT) (i + 1),
                    SQL_PARAM_INPUT, SQL_DEFAULT,
                    SqlType[ColData[i].Type],
                    ColData[i].Type == TYPE_DECIMAL ? ColData[i].Prec
                    : ColData[i].Length,
                    ColData[i].Type == TYPE_DECIMAL ? ColData[i].Scale : 0,
                    CHAR_LIKE(ColData[i].Type) ?
                    (SQLPOINTER) (TextBuf[i] + j * (ColData[i].Length + 1)) :
                (SQLPOINTER) (BinBuf[i] + j * TypeSz[ColData[i].Type]),
                    CHAR_LIKE(ColData[i].Type) ? ColData[i].Length + 1
                    : TypeSz[ColData[i].Type],
                    BufLen[i]), 1))
                    return 0;
                if (OdbcErr(SQLExecDirect(hStmt, (SQLCHAR *) InsStmt, SQL_NTS), 1))
                    return 0;
        }
    }
    if (CurGran == GranNum - 1) {
        for (i = 0; i < ColNum; i++)
            free(BufLen[i]);
        free(BufLen);
        if (OdbcErr(SQLFreeHandle(SQL_HANDLE_STMT, hStmt), 1))
            return 0;
        if (OdbcErr(SQLDisconnect(hDbc), 1))
            return 0;
        if (OdbcErr(SQLFreeHandle(SQL_HANDLE_DBC, hDbc), 1))
            return 0;
        if (OdbcErr(SQLFreeHandle(SQL_HANDLE_ENV, hEnv), 1))
            return 0;
    }
    return 1;
}
#endif
/* ifndef NO_ODBC */
/* Generate() - main generate proc */
int				Generate(void)
{
    int				j;
    __int64			i, n, k;
    char			**TextBuf = NULL, progMsg[SMALLBUFF];
    unsigned char	**BinBuf = NULL;
    if (RowNum <= 0) {
        MsgPrint(0, InitTok[TOK_ROWNUM], " is null", NULL);
        return 0;
    }
    if ((TextBuf = (char **) malloc(ColNum * sizeof(void *))) == NULL
        || (BinBuf = (unsigned char **) malloc(ColNum * sizeof(void *))) == NULL)
        MsgPrint(1, "Unable to malloc", NULL);
    memset(TextBuf, 0, ColNum * sizeof(void *));
    memset(BinBuf, 0, ColNum * sizeof(void *));
    for (i = 0; i < ColNum; i++) {
        if ((TextBuf[i] = (char *) malloc(GRAN_SZ * (ColData[i].Length + 1))) == NULL
            || (TypeSz[ColData[i].Type] && (BinBuf[i] = (unsigned char *)
            malloc(GRAN_SZ * TypeSz[ColData[i].Type])) == NULL))
            MsgPrint(1, "Unable to malloc", NULL);
    }
    n = RowNum / GRAN_SZ + (RowNum % GRAN_SZ != 0);
    for (i = 0; i < n; i++) {
        for (j = 0; j < ColNum; j++) {
            memset(TextBuf[j], 0, GRAN_SZ * (ColData[j].Length + 1));
            if (BinBuf[j])
                memset(BinBuf[j], 0, GRAN_SZ * TypeSz[ColData[j].Type]);
            GranSz = (int) (i == n - 1 && (RowNum % GRAN_SZ != 0) ? RowNum % GRAN_SZ : GRAN_SZ);
            k = min(RowNum, GRAN_SZ * (i + 1));
            sprintf(progMsg, "%I64d records generated, remains %I64d", k, RowNum - k);
#ifndef _CONSOLE
            SendMessage(hSBar, SB_SETTEXT, 0, (LPARAM) progMsg);
#else
            printf("\r%s", progMsg);
#endif
            SetDistr(TextBuf[j], BinBuf[j], j, i);
        }
        if (fDestFile)
            TextWrite(TextBuf, i, n);
#ifndef NO_ODBC
        if (fDestOdbc && !OdbcWrite(TextBuf, BinBuf, i, n))
            return 0;
#endif
    }
    for (i = 0; i < ColNum; i++) {
        if (BinBuf[i] != NULL)
            free(BinBuf[i]);
        free(TextBuf[i]);
    }
    free(BinBuf);
    free(TextBuf);
    return 1;
}
/* InitDistr() set distr params */
void            InitDistr(DistrAT * distrA)
{
    int             i;
    if (distrA->Distr == DISTR_ORD)
        return;
    if (distrA->Distr == DISTR_GAUS || distrA->Distr == DISTR_EXPN)
        i = GEN_DECS - 1;
    else {
        i = 0;
        while (i < GEN_DECS && (__int64) (distrA->Max - distrA->Min) > Prime[i] - 1)
            i++;
        i = min(i, GEN_DECS - 1);
        distrA->Max = min(distrA->Max, Prime[i] - 1 + distrA->Min);
    }
    distrA->Prim = Prime[i];
    distrA->Prim1 = distrA->Prim - 1;
    distrA->Root = Root[i];
    if (distrA->Distr == DISTR_GAUS || distrA->Distr == DISTR_EXPN) {
        distrA->Mean *= distrA->Prim1 / (distrA->Max - distrA->Min);
        distrA->Deviat *= distrA->Prim1 / (distrA->Max - distrA->Min);
    }
    else if (distrA->Distr == DISTR_SSIM || distrA->Distr == DISTR_ZIPF)
        distrA->Deviat /= distrA->Max - distrA->Min;
    return;
}
#ifdef _CONSOLE
int             IntCmp(const void *i0, const void *i1)
{
    if (*(int *) i0 < *(int *) i1)
        return -1;
    else if (*(int *) i0 > *(int *) i1)
        return 1;
    return 0;
}
/* main _CONSOLE */
int				main(int argc, char *argv[])
{
    int				i;
    if (argc != 2) {
        printf("usage: dbgen <ini_file_name>\n");
        return 0;
    }
    if (!InitCol(argv[1])) {
        printf("No/bad init file %s\n", argv[1]);
        return 0;
    }
    for (i = 0; i < ColNum; i++)
        InitDistr(&ColData[i].DistrA);
    if (!SaveConf("dbgen.log")) {
        printf("Unable to save log\n");
        return 0;
    }
    for (UnqCol = 0; UnqCol < ColNum, !ColData[i].fUnique; UnqCol++) ;
    if (UnqCol < ColNum) {
        if ((UnqArr = (int *) malloc(RowNum * sizeof(int))) == NULL) {
            printf("Unable to malloc\n");
            return 0;
        }
        memset(UnqArr, 0, RowNum * sizeof(int));
    }
    if (Generate())
        printf("\nOk\n");
    else
        printf("\nFail\n");
    if (UnqCol < ColNum) {
        qsort(UnqArr, RowNum, sizeof(int), IntCmp);
        for (i = 0; i < RowNum - 1; i++)
            if (UnqArr[i] == UnqArr[i + 1])
                break;
            if (i < RowNum - 1)
                printf("duplicated:%d\n", UnqArr[i]);
            free(UnqArr);
    }
    return 0;
}
#else
/* Align() - align pointer for dlg template struct */
LPWORD          Align(LPWORD p)
{
    ULONG           ul;
    ul = (ULONG) p;
    ul += 3;
    ul >>= 2;
    ul <<= 2;
    return (LPWORD) ul;
}
/* CreateSmallFont() small font */
HFONT           CreateSmallFont(int fUnderline)
{
    HFONT           hFont;
    LOGFONT         lFont;
    memset(&lFont, 0, sizeof(LOGFONT));
    lFont.lfHeight = GetSystemMetrics(SM_CYHSCROLL) - 2;
    lFont.lfWeight = FW_NORMAL;
    lFont.lfCharSet = DEFAULT_CHARSET;
    if (fUnderline)
        lFont.lfUnderline = 1;
    strcpy(lFont.lfFaceName, "Arial");
    hFont = CreateFontIndirect(&lFont);
    return hFont;
}
/* SetSmallFont() used by EnumChildWindows */
int CALLBACK    SetSmallFont(HWND hwnd, LPARAM lParam)
{
    SendMessage(hwnd, WM_SETFONT, (WPARAM) lParam, 1L);
    return 1;
}
/* InitMain() - init main wnd, init template, do some measurements */
int             InitMain(HWND hwnd)
{
    int             i, cx[COL_NUM] = {70, 70, 50, 50, 50, 70, 77, 77, 80, 80, 40, 46};
    int				sb[4] = {320, 390, 490, -1};
    HD_LAYOUT       layoutHd;
    LV_COLUMN       lvCol;
    RECT            rect;
    WINDOWPOS       wpos;
    HFONT           hFont;
    HDC             hDc;
    CreateWindowEx(0, "static", InitTok[TOK_CONNECT], WS_CHILD | WS_VISIBLE, 4, 10, 40, 18,
        hwnd, NULL, hInst, NULL);
    CreateWindowEx(0, "static", InitTok[TOK_OLDODBC], WS_CHILD | WS_VISIBLE, 560, 10, 48, 18,
        hwnd, NULL, hInst, NULL);
    CreateWindowEx(0, "static", InitTok[TOK_TABLE], WS_CHILD | WS_VISIBLE, 4, 36, 90, 18, hwnd,
        NULL, hInst, NULL);
    CreateWindowEx(0, "static", InitTok[TOK_FLDNUM], WS_CHILD | WS_VISIBLE, 120, 36, 70, 18,
        hwnd, NULL, hInst, NULL);
    CreateWindowEx(0, "static", InitTok[TOK_ROWNUM], WS_CHILD | WS_VISIBLE, 234, 36, 78, 18,
        hwnd, NULL, hInst, NULL);
    CreateWindowEx(0, "static", InitTok[TOK_DESTFILE], WS_CHILD | WS_VISIBLE, 404, 36, 90, 18,
        hwnd, NULL, hInst, NULL);
    CreateWindowEx(0, "static", InitTok[TOK_DESTODBC], WS_CHILD | WS_VISIBLE, 470, 36, 90, 18,
        hwnd, NULL, hInst, NULL);
    CreateWindowEx(0, "static", "Settings", WS_CHILD | WS_VISIBLE, 546, 36, 90, 18,
        hwnd, NULL, hInst, NULL);
    hHelp = CreateWindowEx(0, "help", "", WS_CHILD, X_SHT, Y_SHT, W_SHT, H_SHT, hwnd, NULL,
        hInst, NULL);
    hConnect = CreateWindowEx(0, "ComboBox", "", WS_CHILD | WS_VISIBLE |
        WS_TABSTOP | WS_GROUP | CBS_DROPDOWN | WS_VSCROLL,
        46, 6, 504, 64, hwnd, NULL, hInst, NULL);
    ComboBox_AddString(hConnect, CONN_MS);
    ComboBox_AddString(hConnect, CONN_MY);
    hOldOdbc = CreateWindowEx(0, "button", "", WS_CHILD | WS_VISIBLE | WS_GROUP
        | BS_AUTOCHECKBOX, 612, 10, 36, 16, hwnd, NULL, hInst, NULL);
    hTable = CreateWindowEx(WS_EX_STATICEDGE, "edit", "dbgen", WS_CHILD | WS_VISIBLE
        | WS_TABSTOP | WS_GROUP | ES_AUTOHSCROLL, 32, 34, 80, 16, hwnd, NULL, hInst, NULL);
    hFldNum = CreateWindowEx(WS_EX_STATICEDGE, "edit", "1", WS_CHILD | WS_VISIBLE
        | WS_TABSTOP | WS_GROUP | ES_AUTOHSCROLL | ES_NUMBER,
        186, 34, 40, 16, hwnd, NULL, hInst, NULL);
    hRowNum = CreateWindowEx(WS_EX_STATICEDGE, "edit", "1", WS_CHILD | WS_VISIBLE
        | WS_TABSTOP | WS_GROUP | ES_AUTOHSCROLL | ES_NUMBER,
        314, 34, 80, 16, hwnd, NULL, hInst, NULL);
    hDestFile = CreateWindowEx(0, "button", "", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        450, 36, 16, 16, hwnd, NULL, hInst, NULL);
    hDestOdbc = CreateWindowEx(0, "button", "", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        524, 36, 16, 16, hwnd, NULL, hInst, NULL);
    SendMessage(hDestOdbc, BM_SETCHECK, BST_CHECKED, 0);
    SendMessage(hDestFile, BM_SETCHECK, BST_CHECKED, 0);
    CreateWindowEx(0, "button", "Generate", WS_CHILD | WS_VISIBLE | WS_TABSTOP
        | WS_GROUP, 660, 7, 90, 24, hwnd, (HMENU) IDC_OK, hInst, NULL);
    hDc = GetDC(NULL);
    hBmpSave = CreateDIBitmap(hDc, (BITMAPINFOHEADER *) & Bmi, CBM_INIT, SaveBits,
        (BITMAPINFO *) & Bmi, DIB_RGB_COLORS);
    hBmpOpen = CreateDIBitmap(hDc, (BITMAPINFOHEADER *) & Bmi, CBM_INIT, OpenBits,
        (BITMAPINFO *) & Bmi, DIB_RGB_COLORS);
    SendMessage(CreateWindowEx(0, "button", "", WS_CHILD | WS_VISIBLE |
        WS_TABSTOP | WS_GROUP | BS_BITMAP, 586, 32, 20, 20, hwnd,
        (HMENU) IDC_SAVE, hInst, NULL),
        BM_SETIMAGE, IMAGE_BITMAP, (LPARAM) hBmpSave);
    SendMessage(CreateWindowEx(0, "button", "", WS_CHILD | WS_VISIBLE |
        WS_TABSTOP | WS_GROUP | BS_BITMAP, 756, 32, 20, 20, hwnd,
        (HMENU) IDC_LOAD, hInst, NULL),
        BM_SETIMAGE, IMAGE_BITMAP, (LPARAM) hBmpOpen);
    ReleaseDC(NULL, hDc);
    hConfig = CreateWindowEx(WS_EX_STATICEDGE, "edit", "", WS_CHILD | WS_VISIBLE | WS_TABSTOP
        | WS_GROUP | ES_AUTOHSCROLL, 608, 34, 146, 16, hwnd, NULL, hInst, NULL);
    hLv = CreateWindowEx(WS_EX_STATICEDGE, WC_LISTVIEW, "", WS_CHILD | WS_VISIBLE | WS_TABSTOP
        | WS_GROUP | WS_VSCROLL | LVS_REPORT | LVS_OWNERDATA | LVS_ICON,
        X_SHT, Y_SHT, W_SHT, H_SHT, hwnd, NULL, hInst, NULL);
    hTab = CreateWindowEx(0, "tab", "", WS_CHILD | WS_VISIBLE, 2, H_MAIN - 64, 124, 14, hwnd,
        NULL, hInst, NULL);
    hSBar = CreateStatusWindow(WS_CHILD | WS_VISIBLE, "", hwnd, 0);
    hTip = CreateWindowEx(WS_EX_STATICEDGE, "static", "", WS_BORDER | WS_VISIBLE | WS_CHILD,
        0, 0, 0, 0, hwnd, NULL, hInst, NULL);
    memset(&lvCol, 0, sizeof(LV_COLUMN));
    lvCol.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
    lvCol.fmt = LVCFMT_LEFT;
    for (i = 0; i < COL_NUM; i++) {
        lvCol.iSubItem = i;
        lvCol.cx = cx[i];
        lvCol.pszText = InitTok[i];
        ListView_InsertColumn(hLv, i, &lvCol);
    }
    if ((Tmpl = (DLGTEMPLATE *) malloc(16 + sizeof(DLGTEMPLATE) + sizeof(DLGITEMTEMPLATE)))
        == NULL)
        MsgPrint(1, "Unable to malloc", NULL);
    memset(Tmpl, 0, 16 + sizeof(DLGTEMPLATE) + sizeof(DLGITEMTEMPLATE));
    Tmpl->style = WS_VISIBLE | WS_CHILD | WS_POPUP | DS_SETFOREGROUND;
    Tmpl->cdit = 1;
    ItemTmpl = (DLGITEMTEMPLATE *) ((unsigned char *) (Tmpl + 1) + 6);
    ItemTmpl = (DLGITEMTEMPLATE *) Align((LPWORD) ItemTmpl);
    *(WORD *) ((unsigned char *) (ItemTmpl + 1)) = 0xFFFF;
    layoutHd.prc = &rect;
    layoutHd.pwpos = &wpos;
    rect.left = rect.top = 0;
    rect.right = W_SHT;
    rect.bottom = H_SHT;
    SendMessage((HWND) SendMessage(hLv, (0x1000 + 31), 0, 0L), HDM_LAYOUT, 0,
        (LPARAM) (HD_LAYOUT FAR *) & layoutHd);
    LvHdHeight = (short) wpos.cy;
    SendMessage(hLv, LVM_SETEXTENDEDLISTVIEWSTYLE, 0,
        LVS_EX_GRIDLINES | LVS_EX_ONECLICKACTIVATE | LVS_EX_FULLROWSELECT);
    SendMessage(hSBar, SB_SETPARTS, (WPARAM) 4, (LPARAM) sb);
    SendMessage(hSBar, SB_SETTEXT, (WPARAM) 1, (LPARAM) "  v. 99.12.22");
    SendMessage(hSBar, SB_SETTEXT, (WPARAM) 2, (LPARAM) " (c) 1999  J.Gray ");
    hFont = CreateSmallFont(0);
    EnumChildWindows(hwnd, SetSmallFont, (LPARAM) hFont);
#ifdef NO_ODBC
    EnableWindow(hDestOdbc, 0);
    EnableWindow(hOldOdbc, 0);
#endif
    return 1;
}
/* SetTmpl() - set input dlg on iSubItem position */
void            SetTmpl(int iItem, int iSubItem)
{
    int             i, u;
    u = GetDialogBaseUnits();
    Tmpl->x = X_SHT;
    for (i = 0; i < iSubItem; i++)
        Tmpl->x = (short) (Tmpl->x + ListView_GetColumnWidth(hLv, i));
    Tmpl->x = (short) (2 + Tmpl->x * 4 / LOWORD(u));
    Tmpl->cx = (short) (ListView_GetColumnWidth(hLv, iSubItem) * 4 / LOWORD(u) - 2);
    Tmpl->y = (short) (3 + (Y_SHT + LvHdHeight + (iItem - ListView_GetTopIndex(hLv))
        * LviHeight) * 8 / HIWORD(u));
    Tmpl->cy = (short) (LviHeight * 8 / HIWORD(u) - 1);
    ItemTmpl->cx = (short) (Tmpl->cx + 4);
    ItemTmpl->x = -2;
    ItemTmpl->y = -3;
    if (iSubItem == COL_TYPE || iSubItem == COL_DISTR) {
        ItemTmpl->cy = 50;
        *(WORD *) ((unsigned char *) (ItemTmpl + 1) + 2) = 0x0085;
        ItemTmpl->style = WS_VISIBLE | WS_CHILD | WS_OVERLAPPED | CBS_DROPDOWNLIST | WS_VSCROLL;
    }
    else {
        ItemTmpl->cy = (short) (Tmpl->cy + 4);
        *(WORD *) ((unsigned char *) (ItemTmpl + 1) + 2) = 0x0081;
        ItemTmpl->style = WS_VISIBLE | WS_CHILD | WS_OVERLAPPED | ES_AUTOHSCROLL | WS_BORDER;
        if (iSubItem == COL_LENGTH || iSubItem == COL_PREC || iSubItem == COL_SCALE)
            ItemTmpl->style |= ES_NUMBER;
    }
    ListView_SetItemState(hLv, ListView_GetNextItem(hLv, -1, LVNI_SELECTED), 0, 0xFFFF);
    ListView_SetItemState(hLv, iItem, LVIS_FOCUSED | LVIS_SELECTED, 0xF);
}
/* ExtendLv() - extend(shrink) number of lv items */
void            ExtendLv(int NewExt)
{
    int             i, OldExt;
    LVITEM          lvItem;
    char            buf[TINYBUFF];
    OldExt = ListView_GetItemCount(hLv);
    if (OldExt != NewExt) {
        for (i = NewExt; i < OldExt; i++)
            ListView_DeleteItem(hLv, NewExt);
        sprintf(buf, "%d", NewExt);
        Edit_SetText(hFldNum, buf);
        memset(&lvItem, 0, sizeof(LVITEM));
        lvItem.mask = LVIF_TEXT;
        lvItem.pszText = LPSTR_TEXTCALLBACK;
        for (i = OldExt; i < NewExt; i++) {
            lvItem.iItem = i;
            ListView_InsertItem(hLv, &lvItem);
        }
        ListView_SetItemCount(hLv, NewExt);
        ListView_SetItemState(hLv, ListView_GetNextItem(hLv, -1, LVNI_SELECTED), 0, 0xFFFF);
        ListView_SetItemState(hLv, NewExt - 1, LVIS_FOCUSED | LVIS_SELECTED, 0xF);
    }
}
/* SetApp() set app data */
void            SetApp(void)
{
    char            buf[LARGEBUFF];
    Edit_SetText(hConfig, Config);
    SetWindowText(hConnect, Connect);
    Button_SetCheck(hDestOdbc, fDestOdbc);
    Button_SetCheck(hDestFile, fDestFile);
    Button_SetCheck(hOldOdbc, fOldOdbc);
    Edit_SetText(hTable, Table);
    sprintf(buf, "%d", RowNum);
    Edit_SetText(hRowNum, buf);
}
/* DbGenOnCreate() for WM_CREATE of main wnd */
int             DbGenOnCreate(HWND hwnd, CREATESTRUCT * lpCreateStruct)
{
    RECT            rect;
    INITCOMMONCONTROLSEX icc;
    char            buf[LARGEBUFF], *p;
    icc.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icc.dwICC = ICC_USEREX_CLASSES | ICC_LISTVIEW_CLASSES | ICC_BAR_CLASSES;
    InitCommonControlsEx(&icc);
    if (!InitMain(hwnd))
        return 0;
    OldFieldNumProc = (WNDPROC) SetWindowLong(hFldNum, GWL_WNDPROC, (long) FieldNumProc);
    OldLvProc = (WNDPROC) SetWindowLong(hLv, GWL_WNDPROC, (long) LvProc);
    OldSBarProc = (WNDPROC) SetWindowLong(hSBar, GWL_WNDPROC, (long) SBarProc);
    if (InitCol(ArgLine)) {
        sprintf(buf, "Read %s -- Ok", ArgLine);
        GetFullPathName(ArgLine, LARGEBUFF, Config, &p);
    }
    else
        sprintf(buf, "Default settings");
    SendMessage(hSBar, SB_SETTEXT, (WPARAM) 0, (LPARAM) buf);
    SetApp();
    ExtendLv(ColNum);
    ListView_GetItemRect(hLv, 0, &rect, LVIR_LABEL);
    LviHeight = (short) (rect.bottom - rect.top);
    return 1;
}
/* FieldNumProc() new proc for field num */
int CALLBACK    FieldNumProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    char            buf[TINYBUFF];
    int             n;
    switch (uMsg) {
    case WM_KILLFOCUS:
        GetWindowText(hwnd, buf, TINYBUFF);
        n = atoi(buf);
        while (ColNum < n) {
            RawPush((char **) &ColData, &ColNum, &ColNumMax, &DefCol[TYPE_INT], sizeof(ColDataT));
            SetFielName(buf);
            strcpy(ColData[ColNum - 1].Name, buf);
        }
        ColNum = n;
        ExtendLv(ColNum);
        break;
    }
    return CallWindowProc(OldFieldNumProc, hwnd, uMsg, wParam, lParam);
}
/* GetInput() get string of index from Ctrl */
void            GetInput(HWND hWndCtl, int iItem, int iSubItem)
{
    char            buf[SMALLBUFF];
    memset(buf, 0, SMALLBUFF);
    if (iSubItem == COL_TYPE || iSubItem == COL_DISTR)
        *(int *) buf = ComboBox_GetCurSel(hWndCtl);
    else
        Edit_GetText(hWndCtl, buf, SMALLBUFF);
    SetValidCol(buf, &ColData[iItem], iSubItem);
}
/* InputCtrlProc() proc for input control */
int CALLBACK    InputCtrlProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) {
    case WM_GETDLGCODE:
        return DLGC_WANTALLKEYS;
    case WM_KEYDOWN:
        switch (wParam) {
        case VK_RETURN:
            GetInput(hwnd, CurItem, CurSubItem);
            DestroyWindow(GetParent(hwnd));
            break;
        case VK_ESCAPE:
            DestroyWindow(GetParent(hwnd));
            break;
        case VK_TAB:
            if (GetKeyState(VK_SHIFT) & 0x8000)
                SendMessage(hMain, WM_COMMAND, IDC_LEFT, 0);
            else
                SendMessage(hMain, WM_COMMAND, IDC_RIGHT, 0);
            break;
        }
        break;
    case WM_KILLFOCUS:
        GetInput(hwnd, CurItem, CurSubItem);
        MoveWindow(hTip, 0, 0, 0, 0, 1);
        InvalidateRect(hTip, NULL, 1);
        UpdateWindow(hTip);
        DestroyWindow(GetParent(hwnd));
        break;
    case WM_SETFOCUS:
        Edit_SetSel(hwnd, 0, -1);
        break;
    }
    return CallWindowProc(OldInputCtrlProc, hwnd, uMsg, wParam, lParam);
}
/* InputDlgProc() main proc for input dialog */
int CALLBACK    InputDlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    int             i;
    HFONT           hFont;
    char            buf[SMALLBUFF];
    RECT            rc;
    HWND            hwndFocus = (HWND) wParam;
    POINT           pt;
    switch (uMsg) {
    case WM_INITDIALOG:
        hFont = CreateSmallFont(0);
        SendMessage(hwndFocus, WM_SETFONT, (WPARAM) hFont, 1L);
        if (CurSubItem == COL_TYPE) {
            for (i = 0; i < TYPE_NUM; i++)
                ComboBox_AddString(hwndFocus, TypeArr[i]);
            ComboBox_SetCurSel(hwndFocus, ColData[CurItem].Type);
        }
        else if (CurSubItem == COL_DISTR) {
            for (i = 0; i < DISTR_NUM; i++)
                ComboBox_AddString(hwndFocus, DistrArr[i]);
            ComboBox_SetCurSel(hwndFocus, ColData[CurItem].DistrA.Distr);
        }
        else if (CurSubItem != COL_KEY && CurSubItem != COL_UNIQUE) {
            GetColStr(&ColData[CurItem], CurSubItem, buf, SMALLBUFF);
            Edit_SetText(hwndFocus, buf);
        }
        OldInputCtrlProc = (WNDPROC) SetWindowLong(hwndFocus, GWL_WNDPROC, (long) InputCtrlProc);
        if (CurSubItem == COL_STDDEV
            && (ColData[CurItem].DistrA.Distr == DISTR_SSIM
            || ColData[CurItem].DistrA.Distr == DISTR_ZIPF)) {
            GetWindowRect(hwnd, &rc);
            pt.x = rc.left;
            pt.y = rc.bottom + 2;
            ScreenToClient(hMain, &pt);
            MoveWindow(hTip, pt.x, pt.y, 77, 16, 1);
            SetWindowText(hTip, InitTok[TOK_H + ColData[CurItem].DistrA.Distr - DISTR_SSIM]);
            SetForegroundWindow(hTip);
            ShowWindow(hTip, SW_SHOW);
        }
        return 1;
    case WM_COMMAND:
        if (HIWORD(wParam) == CBN_CLOSEUP) {
            GetInput((HWND) lParam, CurItem, CurSubItem);
            DestroyWindow(hwnd);
        }
        break;
    }
    return 0;
}
/* LvProc() new proc for lv */
int CALLBACK    LvProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) {
    case WM_KEYDOWN:
        if (wParam == VK_RETURN && LOWORD(lParam)) {
            CurItem = ListView_GetNextItem(hLv, -1, LVNI_SELECTED);
            CurSubItem = 0;
            SetTmpl(CurItem, CurSubItem);
            CreateDialogIndirect(hInst, Tmpl, hMain, InputDlgProc);
        }
        else if (wParam == VK_TAB && LOWORD(lParam))
            SetFocus(GetNextWindow(hwnd, GW_HWNDNEXT));
        break;
    case WM_GETDLGCODE:
        return DLGC_WANTALLKEYS;
    }
    return CallWindowProc(OldLvProc, hwnd, uMsg, wParam, lParam);
}
/* SBarProc() new proc for status bar */
int CALLBACK    SBarProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    HDC             hdc;
    RECT            rect;
    HFONT           hOldFont, hFont;
    switch (uMsg) {
    case WM_PAINT:
        hdc = GetDC(hwnd);
        hFont = CreateSmallFont(1);
        hOldFont = (HFONT) SelectObject(hdc, hFont);
        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, RGB(0, 0, 0xFF));
        rect.bottom = 18;
        rect.left = 496;
        rect.right = 770;
        rect.top = 3;
        TextOut(hdc, rect.left, rect.top, URL, strlen(URL));
        ValidateRect(hwnd, &rect);
        SelectObject(hdc, hOldFont);
        ReleaseDC(hwnd, hdc);
        DeleteObject(hFont);
        break;
    }
    return CallWindowProc(OldSBarProc, hwnd, uMsg, wParam, lParam);
}
/* DbGenOnNotify() for WM_NOTIFY main wnd */
int             DbGenOnNotify(HWND hwnd, int idFrom, NMHDR * pnmhdr)
{
    int             x, i, j;
    POINT           pt;
    LV_DISPINFO    *di;
    char            buf[SMALLBUFF];
    memset(buf, 0, SMALLBUFF);
    switch (pnmhdr->code) {
    case LVN_GETDISPINFO:
        di = (LV_DISPINFO *) pnmhdr;
        GetColStr(&ColData[di->item.iItem], di->item.iSubItem, buf, SMALLBUFF);
        di->item.pszText = buf;
        return 0;
    case NM_CLICK:
        if (pnmhdr->hwndFrom == hLv) {
            GetCursorPos(&pt);
            ScreenToClient(hwnd, &pt);
            i = (pt.y - Y_SHT - LvHdHeight) / LviHeight
                + ListView_GetTopIndex(hLv);
            if (i < 0 || i >= ColNum) {
                MessageBeep(MB_ICONHAND);
                return 0;
            }
            x = X_SHT;
            for (j = 0; j < COL_NUM; j++) {
                x += ListView_GetColumnWidth(hLv, j);
                if (x >= pt.x)
                    break;
            }
            if (j == COL_NUM) {
                MessageBeep(MB_ICONHAND);
                return 0;
            }
            CurItem = i;
            CurSubItem = j;
            if (j < COL_NUM - 2) {
                if (!EnableCol(ColData[CurItem].Type, ColData[CurItem].DistrA.Distr, CurSubItem))
                    return 0;
                SetTmpl(CurItem, CurSubItem);
                CreateDialogIndirect(hInst, Tmpl, hMain, InputDlgProc);
            }
            else {
                *(int *) buf = (CurSubItem == COL_KEY ?
                    ColData[CurItem].fPrimKey : ColData[CurItem].fUnique);
                SetValidCol(buf, &ColData[CurItem], CurSubItem);
                InvalidateRect(hLv, NULL, 1);
                UpdateWindow(hLv);
            }
        }
        if (pnmhdr->hwndFrom == hSBar) {
            GetCursorPos(&pt);
            ScreenToClient(hwnd, &pt);
            if (pt.x > 490)
                ShellExecute(hMain, "open", URL, 0, 0, SW_SHOWNORMAL);
        }
        break;
    }
    return 0;
}
/* RestoreDistr() restore distr params */
void            RestoreDistr(DistrAT * distrA)
{
    if (distrA->Distr == DISTR_GAUS || distrA->Distr == DISTR_EXPN) {
        distrA->Mean *= (distrA->Max - distrA->Min) / distrA->Prim1;
        distrA->Deviat *= (distrA->Max - distrA->Min) / distrA->Prim1;
    }
    else if (distrA->Distr == DISTR_SSIM || distrA->Distr == DISTR_ZIPF)
        distrA->Deviat *= distrA->Max - distrA->Min;
}
/* GetApp() get app data */
void            GetApp(void)
{
    char            buf[SMALLBUFF];
    Connect[0] = '\0';
    ComboBox_GetText(hConnect, Connect, XLARGEBUFF);
    fDestOdbc = Button_GetCheck(hDestOdbc);
    fDestFile = Button_GetCheck(hDestFile);
    fOldOdbc = Button_GetCheck(hOldOdbc);
    Table[0] = '\0';
    Edit_GetText(hTable, Table, SMALLBUFF);
    buf[0] = '\0';
    Edit_GetText(hRowNum, buf, SMALLBUFF);
    RowNum = atoi(buf);
}
/* DbGenOnCommand() main wnd WM_COMMAND */
void            DbGenOnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    int             i;
    OPENFILENAME    ofn;
    char            buf[LARGEBUFF], *p;
    switch (id) {
    case IDC_OK:
        SetFocus(hMain);
        for (i = 0; i < ColNum; i++)
            InitDistr(&ColData[i].DistrA);
        GetApp();
        if (Generate())
            SendMessage(hSBar, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Output -- Ok.");
        else {
            SendMessage(hSBar, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Output -- Failed.");
            MessageBeep(MB_ICONHAND);
        }
        for (i = 0; i < ColNum; i++)
            RestoreDistr(&ColData[i].DistrA);
        break;
    case IDCANCEL:
        PostQuitMessage(0);
        break;
    case IDC_LEFT:
        GetInput(GetFocus(), CurItem, CurSubItem);
        DestroyWindow(GetParent(GetFocus()));
        do {
            if (CurItem == 0 && CurSubItem == 0)
                return;
            if (CurSubItem > 0)
                CurSubItem--;
            else {
                CurSubItem = COL_NUM - 3;
                if (CurItem > 0)
                    CurItem--;
                else
                    return;
            }
        }
        while (!EnableCol(ColData[CurItem].Type, ColData[CurItem].DistrA.Distr, CurSubItem));
        if (!EnableCol(ColData[CurItem].Type, ColData[CurItem].DistrA.Distr, CurSubItem))
            return;
        ListView_EnsureVisible(hLv, CurItem, 0);
        SetTmpl(CurItem, CurSubItem);
        CreateDialogIndirect(hInst, Tmpl, hMain, InputDlgProc);
        break;
    case IDC_RIGHT:
        GetInput(GetFocus(), CurItem, CurSubItem);
        DestroyWindow(GetParent(GetFocus()));
        do {
            if (CurItem == ColNum - 1 && CurSubItem == COL_NUM - 3)
                return;
            if (CurSubItem < COL_NUM - 3)
                CurSubItem++;
            else {
                CurSubItem = 0;
                if (CurItem < ColNum - 1)
                    CurItem++;
                else
                    return;
            }
        }
        while (!EnableCol(ColData[CurItem].Type, ColData[CurItem].DistrA.Distr, CurSubItem));
        if (!EnableCol(ColData[CurItem].Type, ColData[CurItem].DistrA.Distr, CurSubItem))
            return;
        ListView_EnsureVisible(hLv, CurItem, 0);
        SetTmpl(CurItem, CurSubItem);
        CreateDialogIndirect(hInst, Tmpl, hMain, InputDlgProc);
        break;
    case IDC_SAVE:
        Edit_GetText(hConfig, Config, LARGEBUFF);
        if (Config[0] == 0) {
            memset(&ofn, 0, sizeof(OPENFILENAME));
            ofn.lStructSize = sizeof(OPENFILENAME);
            ofn.hwndOwner = hMain;
            ofn.hInstance = hInst;
            ofn.lpstrFile = Config;
            ofn.nMaxFile = LARGEBUFF;
            ofn.Flags = OFN_HIDEREADONLY | OFN_EXPLORER;
            ofn.lpstrTitle = "File to save current settings";
            if (!GetSaveFileName(&ofn)) {
                memset(Config, 0, LARGEBUFF);
                MessageBeep(MB_ICONHAND);
                return;
            }
            Edit_SetText(hConfig, Config);
        }
        GetApp();
        if (!SaveConf(Config)) {
            SendMessage(hSBar, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Save settings -- Fail.");
            MessageBeep(MB_ICONHAND);
        }
        else
            SendMessage(hSBar, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Save settings -- Ok.");
        break;
    case IDC_LOAD:
        Edit_GetText(hConfig, Config, LARGEBUFF);
        memset(&ofn, 0, sizeof(OPENFILENAME));
        ofn.lStructSize = sizeof(OPENFILENAME);
        ofn.hwndOwner = hMain;
        ofn.hInstance = hInst;
        ofn.lpstrFile = Config;
        ofn.nMaxFile = LARGEBUFF;
        ofn.Flags = OFN_HIDEREADONLY | OFN_EXPLORER;
        ofn.lpstrTitle = "File to load current settings";
        if (!GetSaveFileName(&ofn)) {
            memset(Config, 0, LARGEBUFF);
            MessageBeep(MB_ICONHAND);
            SendMessage(hSBar, SB_SETTEXT, (WPARAM) 0, (LPARAM) "");
            return;
        }
        Edit_SetText(hConfig, Config);
        fDestOdbc = fDestFile = ColNum = 0;
        if (InitCol(Config)) {
            sprintf(buf, "Load settings %s -- Ok", Config);
            GetFullPathName(Config, LARGEBUFF, Config, &p);
        }
        else
            sprintf(buf, "Default settings");
        SendMessage(hSBar, SB_SETTEXT, (WPARAM) 0, (LPARAM) buf);
        SetApp();
        ExtendLv(ColNum);
        break;
    }
}
/* DbGenOnDestroy() main wnd destroy */
void            DbGenOnDestroy(HWND hwnd)
{
    DeleteObject(hBmpSave);
    DeleteObject(hBmpOpen);
    PostQuitMessage(0);
}
/* DbGenOnSize() main wnd size - no change */
void            DbGenOnSize(HWND hwnd, UINT state, int cx, int cy)
{
    RECT            rect;
    GetWindowRect(hMain, &rect);
    MoveWindow(hMain, rect.left, rect.top, W_MAIN, H_MAIN, 1);
}
/* TabDraw() draw tab */
void            TabDraw(HDC hdc, char *str, int bSelected, int x)
{
    POINT           pts[4];
    RECT            rc = {0, 0, 0, 0};
    HPEN            hOldPen;
    SelectObject(hdc, bSelected ? GetStockObject(WHITE_BRUSH ) : GetSysColorBrush(0));
    DrawText(hdc, str, -1, &rc, DT_CALCRECT);
    rc.left += x;
    rc.right += x + 20;
    rc.bottom = rc.top + GetSystemMetrics(SM_CYHSCROLL) - 2;
    pts[0].x = rc.left;
    pts[0].y = rc.top;
    pts[1].x = rc.left + 8;
    pts[1].y = rc.bottom - 1;
    pts[2].x = rc.right - 7;
    pts[2].y = rc.bottom - 1;
    pts[3].x = rc.right - 1;
    pts[3].y = rc.top;
    Polygon(hdc, pts, 4);
    if (!bSelected) {
        pts[2].x--;
        pts[3].x--;
        MoveToEx(hdc, pts[2].x, pts[2].y, NULL);
        LineTo(hdc, pts[3].x, pts[3].y);
    }
    else {
        hOldPen = (HPEN) SelectObject(hdc, GetStockObject(WHITE_PEN));
        MoveToEx(hdc, pts[0].x, pts[0].y, NULL);
        LineTo(hdc, pts[3].x, pts[3].y);
        SelectObject(hdc, hOldPen);
    }
    DrawText(hdc, str, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}
/*  TabOnPaint() tab paint proc */
void            TabOnPaint(HWND hwnd)
{
    PAINTSTRUCT     ps;
    HFONT           hFont, hOldFont;
    LOGFONT         lFont;
    BeginPaint(hwnd, &ps);
    SetBkMode(ps.hdc, TRANSPARENT);
    memset(&lFont, 0, sizeof(LOGFONT));
    lFont.lfHeight = GetSystemMetrics(SM_CYHSCROLL) - 3;
    lFont.lfWeight = FW_NORMAL;
    lFont.lfCharSet = DEFAULT_CHARSET;
    strcpy(lFont.lfFaceName, "Arial");
    hFont = CreateFontIndirect(&lFont);
    hOldFont = (HFONT) SelectObject(ps.hdc, hFont);
    if (fTab == 0) {
        TabDraw(ps.hdc, "   Help    ", 0, 60);
        TabDraw(ps.hdc, "   Main    ", 1, 1);
    }
    else if (fTab == 1) {
        TabDraw(ps.hdc, "   Main    ", 0, 1);
        TabDraw(ps.hdc, "   Help    ", 1, 60);
    }
    SelectObject(ps.hdc, hOldFont);
    EndPaint(hwnd, &ps);
}
/* TabOnLButtonDown() tab click proc */
void            TabOnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{
    if (x > 60 && x < 126 && fTab != 1) {
        fTab = 1;
        ShowWindow(hLv, SW_HIDE);
        ShowWindow(hHelp, SW_SHOWNORMAL);
        SetForegroundWindow(hHelp);
        InvalidateRect(hHelp, NULL, 1);
        UpdateWindow(hHelp);
    }
    else if (x < 60 && fTab != 0) {
        fTab = 0;
        ShowWindow(hHelp, SW_HIDE);
        ShowWindow(hLv, SW_SHOWNORMAL);
        SetForegroundWindow(hLv);
        InvalidateRect(hLv, NULL, 1);
        UpdateWindow(hLv);
    }
    else
        return;
    InvalidateRect(hTab, NULL, 1);
    UpdateWindow(hTab);
}
/* TabProc() tab window proc */
int CALLBACK    TabProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) {
        HANDLE_MSG(hwnd, WM_PAINT, TabOnPaint);
        HANDLE_MSG(hwnd, WM_LBUTTONDOWN, TabOnLButtonDown);
    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
}
/* HelpOnCreate() help wnd create */
int             HelpOnCreate(HWND hwnd, CREATESTRUCT * lpCreateStruct)
{
    LOGFONT         logFont;
    HFONT           hFont = NULL;
    HDC             hDc;
    TEXTMETRIC      tM;
    int             i = 0;
    if ((HelpFl = CreateFile("readme.txt", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_ARCHIVE, 
			(HANDLE) NULL)) != INVALID_HANDLE_VALUE) {
        HelpSz = GetFileSize(HelpFl, NULL);
        if ((HelpMap = CreateFileMapping(HelpFl, NULL, PAGE_READONLY, 0, HelpSz, NULL)) == NULL
            || (HelpBuf = (char *) MapViewOfFile(HelpMap, FILE_MAP_READ, 0, 0, HelpSz)) == NULL);
    }
    while (i < HelpSz)
        if (HelpBuf[i++] == 0xD)
            HelpNum++;
    memset(&logFont, 0, sizeof(LOGFONT));
    strcpy(logFont.lfFaceName, "Arial");
    logFont.lfHeight = 16;
    hFont = CreateFontIndirect(&logFont);
    hDc = GetDC(hwnd);
    SelectFont(hDc, hFont);
    GetTextMetrics(hDc, &tM);
    HelpHeight = tM.tmHeight + tM.tmExternalLeading;
    ReleaseDC(hwnd, hDc);
    return 1;
}
/* HelpOnDestroy() help destroy */
void            HelpOnDestroy(HWND hwnd)
{
    UnmapViewOfFile(HelpBuf);
    CloseHandle(HelpMap);
    CloseHandle(HelpFl);
}
/* HelpOnSize() help size */
void            HelpOnSize(HWND hwnd, UINT state, int cx, int cy)
{
    memset(&HelpSi, 0, sizeof(SCROLLINFO));
    HelpSi.cbSize = sizeof(SCROLLINFO);
    HelpSi.fMask = SIF_RANGE | SIF_POS | SIF_PAGE;
    HelpSi.nMax = HelpNum;
    if (HelpHeight)
        HelpSi.nPage = cy / HelpHeight;
    SetScrollInfo(hwnd, SB_VERT, &HelpSi, 1);
}
/* HelpOnPaint paint help wnd */
void            HelpOnPaint(HWND hwnd)
{
    PAINTSTRUCT     ps;
    RECT            rc;
    int             i = 0, j = 0;
    BeginPaint(hwnd, &ps);
    if (HelpFl == INVALID_HANDLE_VALUE || !HelpMap || !HelpBuf || !HelpNum)
        TextOut(ps.hdc, 2, 2, "No readme.txt in the current dir", strlen("No readme.txt in the current dir"));
    else {
        HelpSi.fMask = SIF_POS;
        GetScrollInfo(hwnd, SB_VERT, &HelpSi);
        while (j < HelpSz && i < HelpSi.nPos)
            if (HelpBuf[j++] == 0xD)
                i++;
        j = min(j, HelpSz - 1);
        GetClientRect(hwnd, &rc);
        DrawText(ps.hdc, &HelpBuf[j], HelpSz - 1 - j, &rc, DT_NOPREFIX);
    }
    EndPaint(hwnd, &ps);
}
/* HelpOnVScroll() help scroll */
void            HelpOnVScroll(HWND hwnd, HWND hwndCtl, UINT code, int pos)
{
    int             yInc;
    RECT            rc;
    switch (code) {
    case SB_PAGEDOWN:
    case SB_LINEDOWN:
        yInc = 1;
        break;
    case SB_PAGEUP:
    case SB_LINEUP:
        yInc = -1;
        break;
    case SB_THUMBTRACK:
        yInc = pos - HelpPos;
        break;
    default:
        yInc = 0;
    }
    GetClientRect(hwnd, &rc);
    if ((yInc = max(-HelpPos, min(yInc,
        max(0, HelpNum + 2 - rc.bottom / HelpHeight) - HelpPos))) != 0) {
        HelpPos += yInc;
        HelpSi.nPos = HelpPos;
        HelpSi.fMask = SIF_POS;
        HelpSi.cbSize = sizeof(SCROLLINFO);
        SetScrollInfo(hwnd, SB_VERT, &HelpSi, 1);
        InvalidateRect(hwnd, NULL, 1);
        UpdateWindow(hwnd);
    }
}
/* HelpProc() help proc */
int CALLBACK    HelpProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
        HANDLE_MSG(hwnd, WM_CREATE, HelpOnCreate);
        HANDLE_MSG(hwnd, WM_DESTROY, HelpOnDestroy);
        HANDLE_MSG(hwnd, WM_SIZE, HelpOnSize);
        HANDLE_MSG(hwnd, WM_PAINT, HelpOnPaint);
        HANDLE_MSG(hwnd, WM_VSCROLL, HelpOnVScroll);
    }
    return DefWindowProc(hwnd, message, wParam, lParam);
}
/* DgMainProc() main wnd proc */
int CALLBACK    DgMainProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) {
        HANDLE_MSG(hwnd, WM_CREATE, DbGenOnCreate);
        HANDLE_MSG(hwnd, WM_COMMAND, DbGenOnCommand);
        HANDLE_MSG(hwnd, WM_NOTIFY, DbGenOnNotify);
        HANDLE_MSG(hwnd, WM_DESTROY, DbGenOnDestroy);
        HANDLE_MSG(hwnd, WM_SIZE, DbGenOnSize);
    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
}
/* WinMain WIN32 */
int WINAPI      WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPTSTR CmdLine, int CmdShow)
{
    MSG             msg;
    WNDCLASSEX      wcex;
    memset(&wcex, 0, sizeof(WNDCLASSEX));
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
    wcex.hInstance = hInstance;
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH) (COLOR_BTNFACE + 1);
    wcex.lpfnWndProc = (WNDPROC) DgMainProc;
    wcex.lpszClassName = InitTok[TOK_DBGEN];
    RegisterClassEx(&wcex);
    wcex.lpfnWndProc = (WNDPROC) TabProc;
    wcex.lpszClassName = "tab";
    RegisterClassEx(&wcex);
    wcex.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
    wcex.lpfnWndProc = (WNDPROC) HelpProc;
    wcex.lpszClassName = "help";
    RegisterClassEx(&wcex);
    hInst = hInstance;
    ArgLine = CmdLine;
    hMain = CreateWindowEx(WS_EX_STATICEDGE, InitTok[TOK_DBGEN], "Database generator",
        WS_CAPTION | WS_SYSMENU | WS_THICKFRAME | WS_MINIMIZEBOX,
        5, 5, W_MAIN, H_MAIN, NULL, NULL, hInst, NULL);
    ShowWindow(hMain, CmdShow);
    UpdateWindow(hMain);
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (!IsDialogMessage(hMain, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    return 0;
}
#endif
